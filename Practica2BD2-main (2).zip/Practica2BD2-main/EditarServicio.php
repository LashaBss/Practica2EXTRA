<?php
session_start();
require_once "conexion.php";

// Obtener el ID del servicio desde el formulario (pasado como POST)
if (isset($_POST['idTipoServicio'])) {
    $idTipoServicio = $_POST['idTipoServicio'];
    
    // Obtener el nombre y la descripción del servicio desde la base de datos
    $sql = "SELECT nombre, descripcion FROM tipo_servicio WHERE idTipo = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $idTipoServicio);
    $stmt->execute();
    $result = $stmt->get_result();

    // Si el servicio existe, obtener los datos
    if ($row = $result->fetch_assoc()) {
        $nombreServicio = $row['nombre'];
        $descripcionServicio = $row['descripcion'];
    } else {
        $_SESSION['error'] = "Servicio no encontrado.";
        header("Location: index.php");
        exit;
    }

    $stmt->close();
} else {
    $_SESSION['error'] = "ID de servicio no especificado.";
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Servicio</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <h1>Editar Servicio: <?php echo htmlspecialchars($nombreServicio); ?></h1>
    
    <!-- Formulario para editar servicio -->
    <form action="insertarCambioServicio.php" method="post">
        <!-- Campo oculto para almacenar el id del servicio -->
        <input type="hidden" name="idTipoServicio" value="<?php echo htmlspecialchars($idTipoServicio); ?>">

        <label for="NombreServicio">Nuevo nombre del servicio</label>
        <input type="text" id="NombreServicio" name="NombreServicio" value="<?php echo htmlspecialchars($nombreServicio); ?>" required>

        <label for="Descripcion">Nueva descripción del servicio</label>
        <input type="text" id="Descripcion" name="Descripcion" value="<?php echo htmlspecialchars($descripcionServicio); ?>" required>

        <button type="submit">Editar Servicio</button>
    </form>

    <?php
    // Mostrar mensaje de error o éxito si está presente
    if (isset($_SESSION['error'])) {
        echo '<p style="color: red;">' . $_SESSION['error'] . '</p>';
        unset($_SESSION['error']);
    }
    if (isset($_SESSION['success'])) {
        echo '<p style="color: green;">' . $_SESSION['success'] . '</p>';
        unset($_SESSION['success']);
    }
    ?>

</body>
</html>
