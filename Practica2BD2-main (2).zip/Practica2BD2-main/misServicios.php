<?php
global $con;
require_once "conexion.php";

session_start(); // Iniciamos la sesión

$nombre = $_SESSION['usuario'];
$correo = $_SESSION['email'];

// Preparamos la consulta para obtener los servicios asociados a este correo electrónico
$sql = "SELECT idServicio, fechaModificacion, precio, etapa, idTipo
        FROM SERVICIO
        WHERE correoElectronicoCliente = '$correo'";



$resultado= mysqli_query($con, $sql);
$serviciosUsuario = [];
while ($fila = mysqli_fetch_assoc($resultado)) {
    $serviciosUsuario[] = $fila;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servicios de $nombre</title>
    <link rel="stylesheet" href="css/estilos.css">
    <style>
        .productos-container {
            display: flex;
            flex-direction: column; /* Listado vertical */
            gap: 20px; /* Espacio entre filas */
        }
        .product {
            display: flex; /* Contenido horizontal */
            justify-content: space-between; /* Espaciado entre columnas */
            align-items: center;
            border-top: 2px solid #000; /* Línea separadora */
            padding: 10px 20px; /* Espaciado interno */
            background-color: #f5f5f5;
            border-radius: 5px;
        }
        .product span {
            font-weight: bold; /* Negrita para el texto adicional */
        }
    </style>
</head>
<body>
<?php
require_once "header.php";
?>
<!-- Catálogo de Productos -->

<h1 class="Hregistro"><?php echo htmlspecialchars($nombre); ?>, estos son tus servicios</h1>
<section class="catalog">
    <div class="productos-container">

        <?php foreach ($serviciosUsuario as $servicio): ?>

            <div class="product">
                <?php
                    $idTipo=$servicio['idTipo'];
                    $sql = "SELECT nombre FROM TIPO_SERVICIO WHERE idTipo = '$idTipo'";
                    $resultado= mysqli_query($con, $sql);
                    $nombreTipo = mysqli_fetch_assoc($resultado)['nombre']
                ?>
                <p><span>Nombre del servicio:</span> <?php echo htmlspecialchars($nombreTipo); ?></p>
                <p><span>Última modificación:</span> <?php echo htmlspecialchars($servicio['fechaModificacion']); ?></p>
                <p><span>Etapa actual:</span> <?php echo htmlspecialchars($servicio['etapa']); ?></p>
                <p><span>Identificador:</span> <?php echo htmlspecialchars($servicio['idServicio']); ?></p>
            </div>
        <?php endforeach; ?>
    </div>

</section>
</body>
</html>
