DROP DATABASE IF EXISTS TOT_CLOUD;
CREATE DATABASE TOT_CLOUD;
USE TOT_CLOUD;

START TRANSACTION;

CREATE TABLE USUARIO (
    correoElectronico VARCHAR(256) PRIMARY KEY,
    contraseña VARCHAR(60) NOT NULL,
    nombre VARCHAR(32) NOT NULL,
    primerApellido VARCHAR(32) NOT NULL,
    segundoApellido VARCHAR(32),
    numeroTelefono VARCHAR(16),
    nombreGrupo ENUM ('Administrador', 'Encargado', 'Cliente') NOT NULL
);

CREATE TABLE PERSONAL (
    correoElectronicoPersonal VARCHAR(256) PRIMARY KEY,
    FOREIGN KEY (correoElectronicoPersonal) REFERENCES USUARIO(correoElectronico)
);

CREATE TABLE CLIENTE (
    correoElectronicoCliente VARCHAR(256) PRIMARY KEY,
    FOREIGN KEY (correoElectronicoCliente) REFERENCES USUARIO(correoElectronico)
);

CREATE TABLE VERSION (
    major INT CHECK (major >= 0),
    minor INT CHECK (minor >= 0),
    patch INT CHECK (patch >= 0),
    PRIMARY KEY (major, minor, patch)
);

CREATE TABLE MOTOR_ALMACENAMIENTO (
    idMotor INT AUTO_INCREMENT PRIMARY KEY,
    tamañoBufer ENUM('64 MB', '1 GB', '16 GB') NOT NULL,
    soporteTransaccion BOOLEAN NOT NULL
);

CREATE TABLE INNODB (
    idMotorInnoDB INT PRIMARY KEY,
    FOREIGN KEY (idMotorInnoDB) REFERENCES MOTOR_ALMACENAMIENTO(idMotor)
);

CREATE TABLE MYISAM (
    idMotorMyIsam INT PRIMARY KEY,
    recuperacionAutomatica BOOLEAN NOT NULL,
    FOREIGN KEY (idMotorMyIsam) REFERENCES MOTOR_ALMACENAMIENTO(idMotor)
);

CREATE TABLE TIPO_SERVICIO (
    nombreTipoServicio VARCHAR(32) PRIMARY KEY,
    descripcion TEXT,
    tipologia ENUM('SaaS','PaaS') NOT NULL
);

CREATE TABLE SERVICIO (
    idServicio INT AUTO_INCREMENT PRIMARY KEY,
    fechaModificacion DATE NOT NULL,
    etapa ENUM('Desarrollo', 'Pruebas', 'Preproducción', 'Producción') NOT NULL,
    correoElectronicoCliente VARCHAR(256),
    nombreTipoServicio VARCHAR(32),
    FOREIGN KEY (correoElectronicoCliente) REFERENCES CLIENTE(correoElectronicoCliente),
    FOREIGN KEY (nombreTipoServicio) REFERENCES TIPO_SERVICIO(nombreTipoServicio)
);

CREATE TABLE PLAN_RESPALDO (
    idPlan INT AUTO_INCREMENT PRIMARY KEY,
    frecuencia ENUM ('Diaria', 'Semanal', 'Mensual') NOT NULL,
    retencion ENUM ('7 días', '15 días', '30 días', '90 días', '180 días', '1 año', '2 años') NOT NULL
);

CREATE TABLE BASE_DE_DATOS (
    idBD INT PRIMARY KEY,
    ipCliente VARCHAR(16) NOT NULL, -- se debe generar aleatoriamente
    almacenamiento ENUM('10 GB', '50 GB', '100 GB', '200 GB', '500 GB', '1 TB', '5 TB', '10 TB') NOT NULL,
    PID INT NOT NULL, -- se debe generar aleatoriamente
    puerto INT NOT NULL, -- se debe generar aleatoriamente
    ipPublica VARCHAR(16) NOT NULL, -- la debe seleccionar el usuario
    ipPrivada VARCHAR(16) NOT NULL, -- se debe generar aleatoriamente
    protocoloTransporte ENUM('IL','SPX','SCTP','TCP','UDP','iSCSI','DCCP') NOT NULL, -- se debe seleccionar aleatoriamente
    protocoloAplicacion ENUM('DHCP','DNS','HTTP','HTTPS','POP3','SMTP','Telnet') NOT NULL, -- se debe seleccionar aleatoriamente
    rutaConfiguracion VARCHAR(256) NOT NULL, -- se debe generar aleatoriamente
    major INT,
    minor INT,
    patch INT,
    idPlan INT,
    FOREIGN KEY (idBD) REFERENCES SERVICIO(idServicio),
    FOREIGN KEY (major, minor, patch) REFERENCES VERSION(major, minor, patch),
    FOREIGN KEY (idPlan) REFERENCES PLAN_RESPALDO(idPlan)
);

CREATE TABLE POSTGRESQL (
    idBDPostgreSQL INT PRIMARY KEY,
    encoding ENUM('UTF8','LATIN1','SQL_ASCII','WIN1252') NOT NULL,
    conexionesMaximas ENUM('100', '1000', '10000', '100000', '1000000') NOT NULL,
    extension ENUM ('OpenFTS','PL/Proxy','PostGIS','PostPIC','Prefix','TexCaller') NOT NULL,
    FOREIGN KEY (idBDPostgreSQL) REFERENCES BASE_DE_DATOS(idBD)
);

CREATE TABLE MYSQL (
    idBDMySQL INT PRIMARY KEY,
    modo ENUM('STRICT', 'ANSI', 'TRADITIONAL', 'NO_ENGINE_SUBSTITUTION') NOT NULL,
    idMotor INT NOT NULL,
    FOREIGN KEY (idBDMySQL) REFERENCES BASE_DE_DATOS(idBD),
    FOREIGN KEY (idMotor) REFERENCES MOTOR_ALMACENAMIENTO(idMotor)
);

CREATE TABLE COPIA_SEGURIDAD_SERVICIO (
    idCopiaServicio INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    estado ENUM('Exitosa','Fallida','En Progreso') NOT NULL,
    configuraciones TEXT NOT NULL,
    idServicio INT,
    FOREIGN KEY (idServicio) REFERENCES SERVICIO(idServicio)
);

CREATE TABLE COPIA_SEGURIDAD_BD (
    idCopiaBD INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM ('Completa', 'Incremental', 'Diferencial') NOT NULL,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    ubicacion VARCHAR(256) NOT NULL, -- se ha de generar aleatoriamente
    tamaño INT NOT NULL, -- se ha de generar aleatoriamente
    estado ENUM('Exitosa','Fallida','En Progreso') NOT NULL, -- se ha de seleccionar aleatoriamente
    idBD INT,
    FOREIGN KEY (idBD) REFERENCES BASE_DE_DATOS(idBD)
);

CREATE TABLE CONEXION_BD (
    idConexionBD INT AUTO_INCREMENT PRIMARY KEY,
    hora TIME NOT NULL,
    fecha DATE NOT NULL,
    idBD INT,
    FOREIGN KEY (idBD) REFERENCES BASE_DE_DATOS(idBD)
);

CREATE TABLE SISTEMA_OPERATIVO (
    idSO INT AUTO_INCREMENT PRIMARY KEY,
    nombreSO ENUM('MacOS','Windows','Ubuntu') NOT NULL,
    major INT,
    minor INT,
    patch INT,
    FOREIGN KEY (major, minor, patch) REFERENCES VERSION(major, minor, patch)
);

CREATE TABLE MAQUINA_VIRTUAL (
    idMaquina INT PRIMARY KEY,
    descripcion TEXT,
    host ENUM('vm-host-01','vm-node-02','server-main', 'db-host-03', 'web-host-04') NOT NULL,
    ip VARCHAR(16),
    idSO INT,
    FOREIGN KEY (idMaquina) REFERENCES SERVICIO(idServicio),
    FOREIGN KEY (idSO) REFERENCES SISTEMA_OPERATIVO(idSO)
);

CREATE TABLE ARQUITECTURA (
    idArquitectura INT AUTO_INCREMENT PRIMARY KEY,
    etapa ENUM('Desarrollo', 'Pruebas', 'Preproducción', 'Producción') NOT NULL,
    tipo ENUM('Microservicios', 'Monolítica', 'Serverless', 'Cliente-Servidor') NOT NULL,
    idMaquina INT,
    FOREIGN KEY (idMaquina) REFERENCES MAQUINA_VIRTUAL(idMaquina)
);

CREATE TABLE COMPONENTE_DE_RED (
    idCompenenteRed INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('NIC','Switch','Router','Firewall','Access Point') NOT NULL,
    etapa ENUM('Desarrollo', 'Pruebas', 'Preproducción', 'Producción') NOT NULL,
    idMaquina INT,
    FOREIGN KEY (idMaquina) REFERENCES MAQUINA_VIRTUAL(idMaquina)
);

CREATE TABLE DISCO_DURO (
    idDiscoDuro INT AUTO_INCREMENT PRIMARY KEY,
    etapa ENUM('Desarrollo', 'Pruebas', 'Preproducción', 'Producción') NOT NULL,
    tipo ENUM('HDD','SSD','NVMe','SATA','SAS') NOT NULL,
    capacidad ENUM('128 GB', '256 GB', '512 GB', '1 TB', '2 TB', '4 TB', '8 TB', '16 TB') NOT NULL,
    idMaquina INT,
    FOREIGN KEY (idMaquina) REFERENCES MAQUINA_VIRTUAL(idMaquina)
);

CREATE TABLE RAM (
    idRam INT AUTO_INCREMENT PRIMARY KEY,
    etapa ENUM('Desarrollo', 'Pruebas', 'Preproducción', 'Producción') NOT NULL,
    capacidad  ENUM('2 GB', '4 GB', '8 GB', '16 GB', '32 GB', '64 GB', '128 GB') NOT NULL,
    generacion ENUM('DDR3', 'DDR4', 'DDR5', 'LPDDR4', 'LPDDR5') NOT NULL,
    idMaquina INT,
    FOREIGN KEY (idMaquina) REFERENCES MAQUINA_VIRTUAL(idMaquina)
);

CREATE TABLE CPU (
    idCPU INT AUTO_INCREMENT PRIMARY KEY,
    etapa ENUM('Desarrollo', 'Pruebas', 'Preproducción', 'Producción') NOT NULL,
    nucleos ENUM('2', '4', '6', '8', '12', '16', '24', '32', '64') NOT NULL,
    generacion ENUM('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13') NOT NULL,
    idMaquina INT,
    FOREIGN KEY (idMaquina) REFERENCES MAQUINA_VIRTUAL(idMaquina)
);

CREATE TABLE SERVIDOR_HTTP (
    idServidor INT PRIMARY KEY,
    puerto1 INT NOT NULL, -- se ha de generar aleatoriamente
    puerto2 INT NOT NULL, -- se ha de generar aleatoriamente
    directorioRaiz VARCHAR(256) NOT NULL, -- se ha de generar aleatoriamente
    estado ENUM ('Activo', 'Inactivo', 'Mantenimiento') NOT NULL,
    fechaCreacion DATE NOT NULL, -- se ha de generar aleatoriamente
    ipPublica VARCHAR(16),
    ipPrivada VARCHAR(16), -- se ha de generar aleatoriamente
    protocoloTransporte ENUM('IL','SPX','SCTP','TCP','UDP','iSCSI','DCCP') NOT NULL, -- se ha de generar aleatoriamente
    rutaConfiguracion VARCHAR(256) NOT NULL,
    major INT,
    minor INT,
    patch INT,
    FOREIGN KEY (idServidor) REFERENCES SERVICIO(idServicio),
    FOREIGN KEY (major, minor, patch) REFERENCES VERSION(major, minor, patch)
);

CREATE TABLE CONEXION_HTTP (
    idConexionHTTP INT AUTO_INCREMENT PRIMARY KEY,
    hora TIME NOT NULL,
    fecha DATE NOT NULL,
    idServidor INT,
    FOREIGN KEY (idServidor) REFERENCES SERVIDOR_HTTP(idServidor)
);

CREATE TABLE PERSONAL_ASIGNADO_A_SERVICIO (
    correoElectronicoPersonal VARCHAR(256),
    idServicio INT,
    PRIMARY KEY (correoElectronicoPersonal, idServicio),
    FOREIGN KEY (correoElectronicoPersonal) REFERENCES PERSONAL(correoElectronicoPersonal),
    FOREIGN KEY (idServicio) REFERENCES SERVICIO(idServicio)
);

COMMIT;

DELIMITER //
CREATE PROCEDURE check_config_issues()
BEGIN
    SELECT idMaquina,'La máquina virtual no tiene asignada una dirección IP.' AS aviso
    FROM MAQUINA_VIRTUAL
    WHERE ip = '' OR ip IS NULL; 
END//
DELIMITER ;

DELIMITER $$

CREATE PROCEDURE RealizarCopiaSeguridad()
BEGIN
    -- Variables locales
    DECLARE fechaActual DATE;
    DECLARE horaActual TIME;
    DECLARE idServicioActual INT;
    DECLARE tipoServicioActual VARCHAR(32);
    DECLARE done BOOLEAN DEFAULT FALSE;

    -- Declaración del cursor
    DECLARE servicioCursor CURSOR FOR
        SELECT s.idServicio, s.nombreTipoServicio AS tipo
        FROM SERVICIO s
        WHERE s.fechaModificacion = CURDATE();


    -- Declaración del handler para manejar el fin del cursor
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Asignación de valores a las variables
    SET fechaActual = CURDATE();
    SET horaActual = CURTIME();

    -- Abrir el cursor para iterar sobre los servicios modificados hoy
    OPEN servicioCursor;

    lectura: LOOP
        FETCH servicioCursor INTO idServicioActual, tipoServicioActual;
        IF done THEN
            LEAVE lectura;
        END IF;

        -- Dependiendo del tipo de servicio, extraer las configuraciones
        CASE tipoServicioActual
            WHEN 'PostgreSQL' THEN
                INSERT INTO COPIA_SEGURIDAD_SERVICIO (fecha, hora, estado, configuraciones, idServicio)
                SELECT fechaActual, horaActual, 'En Progreso',
                       CONCAT('Encoding: ', encoding, ', Extensión: ', extension, ', Conexiones máximas: ', conexionesMaximas),
                       idServicioActual
                FROM POSTGRESQL
                WHERE idBDPostgreSQL = idServicioActual;

            WHEN 'MySQL' THEN
                INSERT INTO COPIA_SEGURIDAD_SERVICIO (fecha, hora, estado, configuraciones, idServicio)
                SELECT fechaActual, horaActual, 'En Progreso',
                       CONCAT('Modo: ', modo, ', Motor: ', idMotor),
                       idServicioActual
                FROM MYSQL
                WHERE idBDMySQL = idServicioActual;

            WHEN 'Servidor HTTP' THEN
                INSERT INTO COPIA_SEGURIDAD_SERVICIO (fecha, hora, estado, configuraciones, idServicio)
                SELECT fechaActual, horaActual, 'En Progreso',
                       CONCAT('Puertos: ', puerto1, '-', puerto2, ', Estado: ', estado, ', IP pública: ', ipPublica, ', Ruta configuración: ', rutaConfiguracion),
                       idServicioActual
                FROM SERVIDOR_HTTP
                WHERE idServidor = idServicioActual;

            WHEN 'Máquina Virtual' THEN
                INSERT INTO COPIA_SEGURIDAD_SERVICIO (fecha, hora, estado, configuraciones, idServicio)
                SELECT fechaActual, horaActual, 'En Progreso',
                       CONCAT('Host: ', host, ', IP: ', ip, ', Descripción: ', descripcion),
                       idServicioActual
                FROM MAQUINA_VIRTUAL
                WHERE idMaquina = idServicioActual;

            -- Agregar más casos si hay más tipos de servicios...

            ELSE
                -- Manejo para tipos desconocidos
                INSERT INTO COPIA_SEGURIDAD_SERVICIO (fecha, hora, estado, configuraciones, idServicio)
                VALUES (fechaActual, horaActual, 'Fallida', 'Tipo desconocido', idServicioActual);
            END CASE;
    END LOOP;

    -- Cerrar el cursor
    CLOSE servicioCursor;

    -- Actualizar el estado de las copias como 'Exitosa'
    UPDATE COPIA_SEGURIDAD_SERVICIO
    SET estado = 'Exitosa'
    WHERE fecha = fechaActual AND hora = horaActual AND estado = 'En Progreso';

END$$

DELIMITER ;

-- Crear el evento programado
DELIMITER $$

CREATE EVENT CopiaSeguridadDiaria
    ON SCHEDULE EVERY 1 DAY
        STARTS '2024-12-14 23:59:59'
    DO
    CALL RealizarCopiaSeguridad();$$

DELIMITER ;