<?php
require_once "conexion.php";
session_start();

// Verificar que el formulario envió datos válidos
if (isset($_POST['TipoServicio'])) {
    $tipoServicio = $_POST['TipoServicio'];
    $_SESSION['TipoServicio'] = $tipoServicio;
} else {
    die("No se seleccionó ningún servicio.");
}


// Función para obtener de la base de datos los datos que nosotros queramos
function obtenerOpciones($tabla, $campo) {
    // Realizamos la consulta
    global $con;
    $query = "SELECT $campo FROM $tabla";
    
    // Ejecutamos la consulta
    $stmt = mysqli_query($con, $query);
    
    // Verificamos si la consulta fue exitosa
    if (!$stmt) {
        die("Error en la consulta: " . mysqli_error($con));
    }
    
    // Inicializamos un array para almacenar los resultados
    $resultados = [];
    
    // Usamos un ciclo para obtener todas las filas
    while ($row = mysqli_fetch_assoc($stmt)) {
        $resultados[] = $row[$campo]; // Almacenamos solo el valor del campo
    }
    
    // Retornamos el array con los resultados
    return $resultados;
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TotCloud</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <h1>Configuración Servicio: <?php echo htmlspecialchars($_SESSION["TipoServicio"]); ?></h1>

    <?php
    // Gestión según el tipo de servicio
    switch ($_SESSION["TipoServicio"]) {
        case 'Base de datos MySQL':
            ?>
            <form action="procesar_configuracion.php" method="POST">
            

                <h2>Configuración avanzada para MySQL</h2>
            
                <!-- Configuración de la base de datos -->
                <h3>Parámetros de la base de datos</h3>
                
                <label for="ipCliente">IP Cliente:</label>
                <input type="text" name="ipCliente" id="ipCliente" placeholder="IP del cliente" required><br>
            
                <label for="almacenamiento">Almacenamiento (GB):</label>
                <input type="number" name="almacenamiento" id="almacenamiento" placeholder="Almacenamiento en GB" required><br>
            
                <label for="PID">PID:</label>
                <input type="number" name="PID" id="PID" placeholder="PID del servicio" required><br>
            
                <label for="puerto">Puerto:</label>
                <input type="number" name="puerto" id="puerto" placeholder="Puerto del servicio" required><br>
            
                <label for="ipPublica">IP Pública:</label>
                <input type="text" name="ipPublica" id="ipPublica" placeholder="IP pública" required><br>
            
                <label for="ipPrivada">IP Privada:</label>
                <input type="text" name="ipPrivada" id="ipPrivada" placeholder="IP privada" required><br>
            
                <label for="protocoloTransporte">Protocolo de transporte:</label>
                <select name="protocoloTransporte" id="protocoloTransporte" required>
                    <option value="IL">IL</option>
                    <option value="SPX">SPX</option>
                    <option value="SCTP">SCTP</option>
                    <option value="TCP">TCP</option>
                    <option value="UDP">UDP</option>
                    <option value="iSCSI">iSCSI</option>
                    <option value="DCCP">DCCP</option>
                </select><br>
            
                <label for="protocoloAplicacion">Protocolo de aplicación:</label>
                <select name="protocoloAplicacion" id="protocoloAplicacion" required>
                    <option value="DHCP">DHCP</option>
                    <option value="DNS">DNS</option>
                    <option value="HTTP">HTTP</option>
                    <option value="HTTPS">HTTPS</option>
                    <option value="POP3">POP3</option>
                    <option value="SMTP">SMTP</option>
                    <option value="Telnet">Telnet</option>
                </select><br>
            
                <label for="rutaConfiguracion">Ruta de configuración:</label>
                <input type="text" name="rutaConfiguracion" id="rutaConfiguracion" placeholder="Ruta del archivo de configuración" required><br>
            
                <!-- Datos de la versión -->
                <h3>Versión de la base de datos</h3>
            
                <label for="major">Major:</label>
                <input type="number" name="major" id="major" placeholder="Versión mayor" required><br>
            
                <label for="minor">Minor:</label>
                <input type="number" name="minor" id="minor" placeholder="Versión menor" required><br>
            
                <label for="patch">Patch:</label>
                <input type="number" name="patch" id="patch" placeholder="Versión de parche" required><br>
            
            

            
                <label for="modo">Modo:</label>
                <select name="modo" id="modo" required>
                    <option value="estricto">Modo estricto</option>
                    <option value="no_estricto">Modo no estricto</option>
                </select><br>
            
                <label for="motor">Motor:</label>
                <select name="motor" id="motor" required>
                    <option value="innodb">InnoDB</option>
                    <option value="myisam">MyISAM</option>
                </select><br>
            
                <label for="tamano_buffer">Tamaño del buffer:</label>
                <select name="tamano_buffer" id="tamano_buffer" required>
                    <option value="1mb">1MB</option>
                    <option value="8mb">8MB</option>
                    <option value="16mb">16MB</option>
                    <option value="32mb">32MB</option>
                </select><br>
            
                <label for="soporte_transacciones">Soporte de transacciones:</label>
                <select name="soporte_transacciones" id="soporte_transacciones" required>
                    <option value="si">Sí</option>
                    <option value="no">No</option>
                </select><br>
            
                <div id="recuperacion_myisam" style="display:none;">
                    <label for="recuperacion">Recuperación automática:</label>
                    <select name="recuperacion" id="recuperacion">
                        <option value="10min">Cada 10 minutos</option>
                        <option value="30min">Cada 30 minutos</option>
                        <option value="1hora">Cada 1 hora</option>
                    </select><br>
                </div>
            
                <input type="hidden" name="TipoServicio" value="Base de datos MySQL">
            
                <button type="submit">Guardar Configuración</button>
            </form>
            
            <script>
                // Mostrar configuración de recuperación automática solo si el motor es MyISAM
                document.getElementById('motor').addEventListener('change', function () {
                    var motorSeleccionado = this.value;
                    if (motorSeleccionado === 'myisam') {
                        document.getElementById('recuperacion_myisam').style.display = 'block';
                    } else {
                        document.getElementById('recuperacion_myisam').style.display = 'none';
                    }
                });
            </script>
            <?php
            break;
            

        case 'Base de datos PostgreSQL':
            ?>
            <form action="procesar_configuracion.php" method="POST">
            <input type="hidden" name="TipoServicio" value="Base de datos PostgreSQL">
    <h2>Configuración avanzada para PostgreSQL</h2>

    <!-- Campo de Encoding -->
    <label for="encoding">Encoding:</label>
    <select name="encoding" id="encoding" required>
        <option value="UTF8">UTF8</option>
        <option value="LATIN1">LATIN1</option>
        <option value="SQL_ASCII">SQL_ASCII</option>
        <option value="WIN1252">WIN1252</option>
    </select><br>

    <!-- Campo de Conexiones máximas -->
    <label for="conexiones_maximas">Conexiones máximas:</label>
    <input type="number" name="conexiones_maximas" id="conexiones_maximas" min="1" value="100" required><br>

    <!-- Campo de Versión -->
    <label for="version">Versión:</label>
    <select name="version" id="version" required>
        <option value="13">13.x</option>
        <option value="14">14.x</option>
        <option value="15">15.x</option>
    </select><br>

    <!-- Campo de Almacenamiento -->
    <label for="almacenamiento">Almacenamiento:</label>
    <select name="almacenamiento" id="almacenamiento" required>
        <option value="default">Tabla por defecto</option>
        <option value="ssd">Almacenamiento en SSD</option>
        <option value="hdd">Almacenamiento en HDD</option>
    </select><br>

    <!-- Campo de Extensiones (selección múltiple) -->
    <label for="extension">Extensiones:</label>
    <select name="extension[]" id="extension" multiple required>
        <option value="PostGIS">PostGIS</option>
        <option value="pg_stat_statements">pg_stat_statements</option>
        <option value="hstore">hstore</option>
        <option value="OpenFTS">OpenFTS</option>
        <option value="PL/Proxy">PL/Proxy</option>
        <option value="PostPIC">PostPIC</option>
        <option value="Prefix">Prefix</option>
        <option value="TexCaller">TexCaller</option>
    </select><br>

    <!-- Campo de Tamaño del buffer -->
    <label for="tamano_buffer_pg">Tamaño del buffer:</label>
    <select name="tamano_buffer_pg" id="tamano_buffer_pg" required>
        <option value="1mb">1MB</option>
        <option value="8mb">8MB</option>
        <option value="16mb">16MB</option>
        <option value="32mb">32MB</option>
    </select><br>

    <!-- Campo de Soporte de transacciones -->
    <label for="soporte_transacciones_pg">Soporte de transacciones:</label>
    <select name="soporte_transacciones_pg" id="soporte_transacciones_pg" required>
        <option value="si">Sí</option>
        <option value="no">No</option>
    </select><br>

    <!-- Campos de la base de datos -->
    <h3>Datos de la base de datos</h3>

    <!-- IP Cliente -->
    <label for="ipCliente">IP Cliente:</label>
    <input type="text" name="ipCliente" id="ipCliente" value="192.168.1.1" required><br>

    <!-- Almacenamiento (GB) -->
    <label for="almacenamiento_bd">Almacenamiento (GB):</label>
    <input type="number" name="almacenamiento_bd" id="almacenamiento_bd" min="1" required><br>

    <!-- PID -->
    <label for="PID">PID:</label>
    <input type="number" name="PID" id="PID" min="1" required><br>

    <!-- Puerto -->
    <label for="puerto">Puerto:</label>
    <input type="number" name="puerto" id="puerto" min="1" required><br>

    <!-- IP Pública -->
    <label for="ipPublica">IP Pública:</label>
    <input type="text" name="ipPublica" id="ipPublica" value="203.0.113.1" required><br>

    <!-- IP Privada -->
    <label for="ipPrivada">IP Privada:</label>
    <input type="text" name="ipPrivada" id="ipPrivada" value="192.168.0.1" required><br>

    <!-- Protocolo de Transporte -->
    <label for="protocoloTransporte">Protocolo de Transporte:</label>
    <select name="protocoloTransporte" id="protocoloTransporte" required>
        <option value="TCP">TCP</option>
        <option value="UDP">UDP</option>
        <option value="iSCSI">iSCSI</option>
        <option value="DCCP">DCCP</option>
        <option value="SPX">SPX</option>
        <option value="SCTP">SCTP</option>
        <option value="IL">IL</option>
    </select><br>

    <!-- Protocolo de Aplicación -->
    <label for="protocoloAplicacion">Protocolo de Aplicación:</label>
    <select name="protocoloAplicacion" id="protocoloAplicacion" required>
        <option value="DHCP">DHCP</option>
        <option value="DNS">DNS</option>
        <option value="HTTP">HTTP</option>
        <option value="HTTPS">HTTPS</option>
        <option value="POP3">POP3</option>
        <option value="SMTP">SMTP</option>
        <option value="Telnet">Telnet</option>
    </select><br>

    <!-- Ruta de configuración -->
    <label for="rutaConfiguracion">Ruta de configuración:</label>
    <input type="text" name="rutaConfiguracion" id="rutaConfiguracion" value="/etc/postgresql/config" required><br>

    <!-- Versión -->
    <input type="hidden" name="major" value="13">
    <input type="hidden" name="minor" value="0">
    <input type="hidden" name="patch" value="1">

    <!-- ID del Plan (asumido como un valor por defecto) -->
    <input type="hidden" name="idPlan" value="1">

    <button type="submit">Guardar Configuración</button>
</form>

            <?php
            break;

        case 'Servidor HTTP':
            ?>
<form action="procesar_configuracion.php" method="POST">
    <h2>Configuración de Servidor HTTP</h2>

    <!-- Campo para el directorio raíz -->
    <label for="directorio_raiz">Directorio raíz:</label>
    <input type="text" name="directorio_raiz" id="directorio_raiz" placeholder="Ruta al directorio raíz" required><br>

    <!-- Campo para el primer puerto -->
    <label for="puerto1">Puerto 1:</label>
    <input type="number" name="puerto1" id="puerto1" placeholder="Puerto 1" required><br>

    <!-- Campo para el segundo puerto -->
    <label for="puerto2">Puerto 2:</label>
    <input type="number" name="puerto2" id="puerto2" placeholder="Puerto 2" required><br>

    <!-- Campo para el estado -->
    <label for="estado">Estado:</label>
    <select name="estado" id="estado" required>
        <option value="Activo">Activo</option>
        <option value="Inactivo">Inactivo</option>
        <option value="Mantenimiento">Mantenimiento</option>
    </select><br>

    <!-- Campo para la IP pública -->
    <label for="ipPublica">IP Pública:</label>
    <input type="text" name="ipPublica" id="ipPublica" placeholder="IP Pública" required><br>

    <!-- Campo para la IP privada -->
    <label for="ipPrivada">IP Privada:</label>
    <input type="text" name="ipPrivada" id="ipPrivada" placeholder="IP Privada" required><br>

    <!-- Campo para el protocolo de transporte -->
    <label for="protocoloTransporte">Protocolo de Transporte:</label>
    <select name="protocoloTransporte" id="protocoloTransporte" required>
        <option value="IL">IL</option>
        <option value="SPX">SPX</option>
        <option value="SCTP">SCTP</option>
        <option value="TCP">TCP</option>
        <option value="UDP">UDP</option>
        <option value="iSCSI">iSCSI</option>
        <option value="DCCP">DCCP</option>
    </select><br>

    <!-- Campo para la ruta de configuración -->
    <label for="rutaConfiguracion">Ruta de configuración:</label>
    <input type="text" name="rutaConfiguracion" id="rutaConfiguracion" placeholder="Ruta al archivo de configuración" required><br>

    <!-- Campos para la versión (major, minor, patch) -->
    <label for="major">Versión Major:</label>
    <input type="number" name="major" id="major" placeholder="Major" required><br>

    <label for="minor">Versión Minor:</label>
    <input type="number" name="minor" id="minor" placeholder="Minor" required><br>

    <label for="patch">Versión Patch:</label>
    <input type="number" name="patch" id="patch" placeholder="Patch" required><br>

    <!-- Campo oculto para especificar el tipo de servicio -->
    <input type="hidden" name="TipoServicio" value="Servidor HTTP">

    <!-- Botón de envío -->
    <button type="submit">Guardar Configuración</button>
</form>
<?php
            break;

        case 'Máquina Virtual':
            ?>
            <form action="procesar_configuracion.php" method="POST">
                <h2>Configuración para la Máquina Virtual</h2>
                <label for="arquitectura">Tipo de arquitectura:</label>
                <select name="arquitectura" id="arquitectura">
                    <option value="x86_64">x86_64</option>
                    <option value="arm">ARM</option>
                    <option value="mips">MIPS</option>
                    <option value="riscv">RISC-V</option>
                </select><br>

                <label for="num_serie_red">Número de serie de la tarjeta de red:</label>
                <input type="text" name="num_serie_red" id="num_serie_red" placeholder="Ej. 00:1A:2B:3C:4D:5E"><br>

                <label for="disco_duro">Disco duro:</label>
                <select name="disco_duro" id="disco_duro">
                    <option value="hdd">HDD</option>
                    <option value="ssd">SSD</option>
                </select><br>

                <label for="cpu">CPU:</label>
                <input type="text" name="cpu" id="cpu" placeholder="Modelo y frecuencia" required><br>

                <label for="memoria_ram">Memoria RAM (GB):</label>
                <input type="number" name="memoria_ram" id="memoria_ram" min="1" required><br>

                <label for="sistema_operativo">Sistema operativo:</label>
                <select name="sistema_operativo" id="sistema_operativo">
                    <option value="1">Ubuntu 20.04</option>
                    <option value="2">CentOS 8</option>
                    <option value="3">Debian 11</option>
                </select><br>

                <input type="hidden" name="TipoServicio" value="Máquina Virtual"; ?>

                <button type="submit">Guardar Configuración</button>
            </form>
            <?php
            break;

        default:
            echo "<p>Tipo de servicio no reconocido.</p>";
            break;
    }
    ?>
</body>
</html>
