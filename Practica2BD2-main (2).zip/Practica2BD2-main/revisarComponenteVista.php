<?php
session_start();
// Incluimos la conexión a la base de datos
include('conexion.php');

// Consulta para obtener los componentes
$sql = "SELECT 
            d.numeroSerie AS DiscoDuro_NumeroSerie, d.tipo AS DiscoDuro_Tipo, d.etapa AS DiscoDuro_Etapa, 
            r.numeroSerie AS RAM_NumeroSerie, r.capacidad AS RAM_Capacidad, r.modelo AS RAM_Modelo, r.generacion AS RAM_Generacion, r.etapa AS RAM_Etapa,
            c.numeroSerie AS CPU_NumeroSerie, c.modelo AS CPU_Modelo, c.nucleos AS CPU_Nucleos, c.hilos AS CPU_Hilos, c.generacion AS CPU_Generacion, c.etapa AS CPU_Etapa,
            cr.numeroSerie AS ComponenteRed_NumeroSerie, cr.tipo AS ComponenteRed_Tipo, cr.etapa AS ComponenteRed_Etapa
        FROM 
            MAQUINA_VIRTUAL mv
        LEFT JOIN DISCO_DURO d ON mv.idMaquina = d.idMaquina
        LEFT JOIN RAM r ON mv.idMaquina = r.idMaquina
        LEFT JOIN CPU c ON mv.idMaquina = c.idMaquina
        LEFT JOIN COMPONENTE_DE_RED cr ON mv.idMaquina = cr.idMaquina";
        
$result = $con->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Componentes</title>
    <link rel="stylesheet" href="css/estilos.css">  <!-- Archivo CSS para los estilos -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: flex-start; /* Alineamos al inicio para que no se "pegue" al centro */
            min-height: 100vh; /* Garantizamos que el body cubra toda la altura */
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            max-width: 800px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column; /* Asegura que los elementos estén en columna */
            align-items: center; /* Centra los elementos dentro del contenedor */
        }

        .title {
            text-align: center;
            font-size: 2.5em; /* Aseguramos que el título sea grande */
            margin-bottom: 30px; /* Aumentamos el margen inferior para mejor separación */
        }

        .component-section {
            width: 100%;
            margin-bottom: 20px;
        }

        .component-section h2 {
            font-size: 2em;
            text-align: center;
            margin-bottom: 15px;
            color: #333;
        }

        .component-section table {
            width: 100%;
            margin-top: 10px;
            border-collapse: collapse;
        }

        .component-section th, .component-section td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .component-section button {
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
        }

        .component-section button:hover {
            background-color: #45a049;
        }

        .back-button {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-size: 1em;
        }

        .back-button:hover {
            background-color: #0056b3;
        }

        .stage-select {
            padding: 5px;
            margin-right: 10px;
        }

        .submit-button {
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 1em;
        }

        .submit-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="title">Revisión y Modificación de Componentes</h1>

        <a href="index.php" class="back-button">Volver a la Página Principal</a>

        <!-- Mostrar cada componente en su propia sección -->
        <?php
        if ($result->num_rows > 0) {
            // Mostrar cada fila de componentes
            while ($row = $result->fetch_assoc()) {
                ?>
                <div class="component-section">
                    <h2>Disco Duro</h2> <!-- Título del componente -->
                    <p><strong>Número de Serie:</strong> <?php echo $row['DiscoDuro_NumeroSerie']; ?></p>
                    <p><strong>Tipo:</strong> <?php echo $row['DiscoDuro_Tipo']; ?></p>
                    <p><strong>Etapa Actual:</strong> <?php echo $row['DiscoDuro_Etapa']; ?></p>
                    <form action="modificarEtapa.php" method="POST">
                        <input type="hidden" name="tipo_componente" value="DiscoDuro">
                        <input type="hidden" name="numero_serie" value="<?php echo $row['DiscoDuro_NumeroSerie']; ?>">
                        <select name="nueva_etapa" class="stage-select">
                            <option value="Desarrollo">Desarrollo</option>
                            <option value="Pruebas">Pruebas</option>
                            <option value="Preproducción">Preproducción</option>
                            <option value="Producción">Producción</option>
                        </select>
                        <button type="submit" class="submit-button">Modificar</button>
                    </form>
                </div>

                <div class="component-section">
                    <h2>RAM</h2> <!-- Título del componente -->
                    <p><strong>Número de Serie:</strong> <?php echo $row['RAM_NumeroSerie']; ?></p>
                    <p><strong>Modelo:</strong> <?php echo $row['RAM_Modelo']; ?></p>
                    <p><strong>Etapa Actual:</strong> <?php echo $row['RAM_Etapa']; ?></p>
                    <form action="modificarEtapa.php" method="POST">
                        <input type="hidden" name="tipo_componente" value="RAM">
                        <input type="hidden" name="numero_serie" value="<?php echo $row['RAM_NumeroSerie']; ?>">
                        <select name="nueva_etapa" class="stage-select">
                            <option value="Desarrollo">Desarrollo</option>
                            <option value="Pruebas">Pruebas</option>
                            <option value="Preproducción">Preproducción</option>
                            <option value="Producción">Producción</option>
                        </select>
                        <button type="submit" class="submit-button">Modificar</button>
                    </form>
                </div>
                <!-- Repetir lo mismo para CPU y Componente de Red si se desea -->
                <?php
            }
        } else {
            echo "<p>No hay componentes disponibles.</p>";
        }
        ?>
    </div>
</body>
</html>
