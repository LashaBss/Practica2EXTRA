<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'tot_cloud';

// Detectar el sistema operativo
$os = PHP_OS;

// Si es macOS (Darwin)
if (stripos($os, 'Darwin') !== false) {
    $port = null;
    $socket = '/Applications/XAMPP/xamppfiles/var/mysql/mysql.sock';
    $con = mysqli_connect($host, $user, $password, $database, $port, $socket)
    or die("No se pudo conectar a la base de datos (macOS)");
} else {
    // Otros sistemas operativos (Windows, Linux, etc.)
    $con = mysqli_connect($host, $user, $password, $database)
    or die("No se pudo conectar a la base de datos (Otros SO)");
}
?>
