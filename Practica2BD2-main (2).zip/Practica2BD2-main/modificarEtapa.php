<?php
// Incluimos la conexión a la base de datos
include('conexion.php');
session_start();

// Verificar si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtenemos los datos enviados desde el formulario
    $tipoComponente = $_POST['tipo_componente'];  // Tipo del componente (DiscoDuro, RAM, CPU, etc.)
    $numeroSerie = $_POST['numero_serie'];        // Número de serie del componente
    $nuevaEtapa = $_POST['nueva_etapa'];          // Nueva etapa seleccionada por el usuario
    
    // Dependiendo del tipo de componente, actualizamos la tabla correspondiente
    if ($tipoComponente == "DiscoDuro") {
        // Actualizamos la etapa del Disco Duro
        $sql = "UPDATE DISCO_DURO SET etapa = ? WHERE numeroSerie = ?";
    } elseif ($tipoComponente == "RAM") {
        // Actualizamos la etapa de la RAM
        $sql = "UPDATE RAM SET etapa = ? WHERE numeroSerie = ?";
    } elseif ($tipoComponente == "CPU") {
        // Actualizamos la etapa de la CPU
        $sql = "UPDATE CPU SET etapa = ? WHERE numeroSerie = ?";
    } elseif ($tipoComponente == "ComponenteRed") {
        // Actualizamos la etapa del Componente de Red
        $sql = "UPDATE COMPONENTE_DE_RED SET etapa = ? WHERE numeroSerie = ?";
    }

    // Preparamos la consulta para evitar inyecciones SQL
    if ($stmt = $con->prepare($sql)) {
        // Vinculamos los parámetros (nueva etapa y número de serie)
        $stmt->bind_param("ss", $nuevaEtapa, $numeroSerie);

        // Ejecutamos la consulta
        if ($stmt->execute()) {
            // Redirigimos al usuario a la página principal después de modificar la etapa
            $_SESSION["mensaje"]="Componente modificado correctamente";
            header("Location: index.php");
            exit();
        } else {
            echo "Error al actualizar la etapa: " . $stmt->error;
        }

        // Cerramos la declaración
        $stmt->close();
    } else {
        echo "Error al preparar la consulta: " . $con->error;
    }
}
?>
