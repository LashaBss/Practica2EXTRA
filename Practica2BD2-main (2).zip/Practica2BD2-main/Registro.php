<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro y Catálogo</title>
    <link rel="stylesheet" href="css/estilos.css">
    <style>
       
    </style>
</head>
<body>
    <header class="Hregistro">
        <h1>Registro de Usuarios y Catálogo de Productos</h1>
        
    </header>

    <div class="container">
        <!-- Formulario de Registro -->
        <?php
            if (isset($_SESSION['error'])) {
                echo "<p style='color: red;'>" . $_SESSION['error'] . "</p>";
                unset($_SESSION['error']); // Elimina el mensaje de error después de mostrarlo
            }
        ?>
        <section class="form-container">
            <h2>Registro de Usuario</h2>
            <form action="insertarUsuarioBD.php" method="POST">

                <label for="nombre">Nombre:</label>
                <input type="input" id="name" name="nombre" required>

                <label for="apellido"> Primer apellido:</label>
                <input type="input" id="apellido" name="apellido1" required>

                <label for="apellido"> Segundo apellido:</label>
                <input type="input" id="apellido" name="apellido2">

                <label for="email">Correo electrónico:</label>
                <input type="email" id="email" name="email" required>

                <label for="teléfono ">Número Teléfono:</label>
                <input type="input" id="Ntelefono" name="Ntelefono" required>

                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Registrarse</button>
            </form>

            <a href="login.php">login</a>
        </section>
