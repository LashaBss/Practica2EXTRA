<?php

require_once "conexion.php";
session_start();

$nombre = $_POST["NombreServicio"];
$descripcion = $_POST["Descripcion"];
$tipoServicioId = $_POST["idTipoServicio"]; // Usamos el id enviado desde el formulario

// Validar que los datos no estén vacíos
if (empty($nombre) || empty($descripcion)) {
    $_SESSION['error'] = "Por favor, complete todos los campos.";
    header("Location: EditarServicio.php"); // Redirige de vuelta al formulario
    exit;
}

// Preparar la consulta para actualizar el servicio
$sql = "UPDATE tipo_servicio SET nombre = ?, descripcion = ? WHERE idTipo = ?";

$stmt = $con->prepare($sql);

if ($stmt === false) {
    $_SESSION['error'] = "Error al preparar la consulta: " . $con->error;
    header("Location: EditarServicio.php");
    exit;
}

// Vincular los parámetros y ejecutar la consulta
$stmt->bind_param("ssi", $nombre, $descripcion, $tipoServicioId);

if ($stmt->execute()) {
    $_SESSION['success'] = "Servicio actualizado correctamente.";
    header("Location: index.php");
    exit;
} else {
    $_SESSION['error'] = "Error al actualizar el servicio: " . $stmt->error;
    header("Location: EditarServicio.php");
    exit;
}

$stmt->close();
$con->close();
?>