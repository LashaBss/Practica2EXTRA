<?php
global $con;
require_once "conexion.php";
session_start();

if (isset($_SESSION["usuario"])) {
    // Obtener el nombre del usuario de la sesión
    $nombreUsuario = $_SESSION['usuario'];
}

// Mostrar el mensaje si existe en la sesión
if (isset($_SESSION['mensaje'])) {
    echo "<div class='alerta'>" . $_SESSION['mensaje'] . "</div>";
    
    // Eliminar el mensaje de la sesión después de mostrarlo
    unset($_SESSION['mensaje']);
}


$sql = "SELECT
    S.idTipo,
    S.nombre,
    S.descripcion
FROM
    TIPO_SERVICIO S";

$resultado = mysqli_query($con, $sql);
$servicios = [];
while ($fila = mysqli_fetch_assoc($resultado)) {
    $servicios[] = $fila;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CatalogoTotCloud</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <?php
        require_once "header.php";
    ?>
    <!-- Catálogo de Productos -->
    <h1 class="Hregistro">Catálogo Tot Cloud</h1>
    <?php
        if (isset($_SESSION["grupo"]) && $_SESSION["grupo"] == "Administrador") {
            ?>
                <h2>Perfil de Administrador</h2>
            <?php
        } else if (isset($_SESSION["grupo"]) && $_SESSION["grupo"] == "Personal") {
            ?>
                <h2>Perfil de Personal</h2>
            <?php
        } else {
            ?>
                <h2>Consulta nuestros Servicios</h2>
            <?php
        }
    ?>
    <section class="catalog">
        <div class="productos-container">
            <?php foreach ($servicios as $servicio): ?>
                <div class="product">
                    <h3><?php echo htmlspecialchars($servicio['nombre']); ?></h3>
                    <p><?php echo htmlspecialchars($servicio['descripcion']); ?></p>

                    <?php
                        // Guardar el servicio en la sesión
                        $_SESSION["servicio_" . $servicio['idTipo']] = $servicio;
                        
                        if (isset($_SESSION["grupo"]) && $_SESSION["grupo"] == "Administrador") {
                            ?>   
                                <form action="EditarServicio.php" method="post">
                                    <!-- Enviar el ID del servicio para que se pueda editar correctamente -->
                                    <input type="hidden" name="idTipoServicio" value="<?php echo htmlspecialchars($servicio['idTipo']); ?>">

                                    <button type="submit">Editar Servicio</button>
                                </form>
                            <?php
                        } else {
                            ?>
                                <form action="ContratarServicio.php" method="post">
                                    <input type="hidden" name="TipoServicio" value="<?php echo htmlspecialchars($servicio['nombre'], ENT_QUOTES, 'UTF-8'); ?>">
                                    <button type="submit"> Contratar Servicio </button>
                                </form>
                            <?php
                        }
                    ?>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</body>
</html>
