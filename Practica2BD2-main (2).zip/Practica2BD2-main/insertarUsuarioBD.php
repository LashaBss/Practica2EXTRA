<?php
global $con;
session_start(); // Inicia la sesión
require_once "conexion.php";

$nombre = $_POST["nombre"];
$apellido1 = $_POST["apellido1"];
$apellido2 = $_POST["apellido2"];
$email = $_POST["email"];
$Ntelefono = $_POST["Ntelefono"];
$password = $_POST["password"];
$nombreGrupo = "Cliente"; // Define el valor como una variable

// Validar que los datos no estén vacíos
if (empty($nombre) || empty($apellido1) || empty($email) || empty($Ntelefono) || empty($password)) {
    $_SESSION['error'] = "Por favor, complete todos los campos.";
    header("Location: formularioRegistro.php"); // Redirige de vuelta al formulario
    exit;
}

// Encriptamos contraseña
$password_hash = password_hash($password, PASSWORD_BCRYPT);

// Preparamos consulta SQL
$sql2 = "INSERT INTO usuario (nombre, primerApellido, segundoApellido, correoElectronico, Numerotelefono, contraseña, nombreGrupo) VALUES (?, ?, ?, ?, ?, ?, ?)";
$sql3 = "INSERT INTO cliente(correoElectronicoCliente) VALUES(?)";
// Preparamos la consulta
$resultado = mysqli_prepare($con, $sql2);
$resultado2 = mysqli_prepare($con, $sql3);
if ($resultado === false) {
    $_SESSION['error'] = "Error al preparar la consulta: " . mysqli_error($con);
    header("Location: formularioRegistro.php");
    exit;
}

// Asociar los parámetros a la consulta preparada
mysqli_stmt_bind_param($resultado, "sssssss", $nombre, $apellido1, $apellido2, $email, $Ntelefono, $password_hash, $nombreGrupo);

// Ejecutar la consulta y verificar el resultado
if (mysqli_stmt_execute($resultado)) {

    $resultado2 = mysqli_prepare($con, $sql3);
    //Guardar usuario de la sesión
    $_SESSION["usuario"]= $nombre;
    $_SESSION["email"] = $email;
    // Redirigir al catálogo de clientes si el registro fue exitoso
    header("Location: index.php");
    exit;
} else {
    // Obtener el código de error
    $errorCode = mysqli_errno($con);
    
    if ($errorCode === 1062) {
        $_SESSION['error'] = "El correo electrónico ya está registrado.";
    } else {
        $_SESSION['error'] = "Error al registrar usuario: " . mysqli_error($con);
    }
    header("Location: Registro.php");
    exit;
}

// Cerrar la consulta y la conexión
mysqli_stmt_close($resultado);
mysqli_close($con);
?>
