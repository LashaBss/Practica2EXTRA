<?php
global $con;
require_once "conexion.php";
session_start();

// Verificar que el formulario envió datos válidos
if (!isset($_POST['TipoServicio'])) {
    die("Error: No se especificó el tipo de servicio.");
}

// Recoger el tipo de servicio desde el formulario
$tipoServicio = $_POST['TipoServicio'];

switch ($tipoServicio) {
    case 'Máquina Virtual':
        // Paso 1: Insertar en la tabla SERVICIO para obtener el idServicio
        $fechaModificacion = date('Y-m-d H:i:s');
        $precio = 100.00; // Puedes ajustar el precio según tu lógica
        $etapa = 'Producción'; // Etapa por defecto

        if (!isset($_SESSION['email'])) {
            die("Error: Usuario no autenticado. Por favor, inicie sesión.");
        }

        $correoElectronicoCliente = $_SESSION['email'];
        $idTipo = 1; // Tipo específico para Máquina Virtual

        $queryServicio = "INSERT INTO SERVICIO (fechaModificacion, precio, etapa, correoElectronicoCliente, idTipo) 
                          VALUES (?, ?, ?, ?, ?)";
        $stmtServicio = mysqli_prepare($con, $queryServicio);
        mysqli_stmt_bind_param($stmtServicio, 'sdssi', $fechaModificacion, $precio, $etapa, $correoElectronicoCliente, $idTipo);

        if (mysqli_stmt_execute($stmtServicio)) {
            // Obtener el idServicio generado automáticamente
            $idServicio = mysqli_insert_id($con); // idServicio = idMaquina
            //echo "Servicio guardado correctamente. ID del servicio: $idServicio.<br>";
        } else {
            die("Error al guardar el servicio: " . mysqli_error($con));
        }

        // Paso 2: Insertar en la tabla MAQUINA_VIRTUAL, usando el idServicio como idMaquina
        $arquitectura = $_POST['arquitectura']; // Tipo de arquitectura
        $numSerieRed = $_POST['num_serie_red']; // Número de serie de la tarjeta de red
        $discoDuro = $_POST['disco_duro']; // Tipo de disco duro
        $cpu = $_POST['cpu']; // CPU (modelo y frecuencia)
        $memoriaRam = intval($_POST['memoria_ram']); // Memoria RAM en GB
        $sistemaOperativo = intval($_POST['sistema_operativo']); // Sistema operativo

        // Insertar en la tabla MAQUINA_VIRTUAL utilizando idServicio como idMaquina
        $queryMaquina = "INSERT INTO MAQUINA_VIRTUAL (idMaquina, descripcion, host, ip, idSO) 
                         VALUES (?, ?, ?, ?, ?)";
        $stmtMaquina = mysqli_prepare($con, $queryMaquina);
        mysqli_stmt_bind_param($stmtMaquina, 'isssi', $idServicio, $descripcion, $host, $ip, $sistemaOperativo);

        if (mysqli_stmt_execute($stmtMaquina)) {
            //echo "Máquina Virtual guardada correctamente. ID de la máquina: $idServicio.<br>"; // Usamos idServicio como idMaquina
        } else {
            die("Error al guardar la máquina virtual: " . mysqli_error($con));
        }

        // Paso 3: Insertar en la tabla ARQUITECTURA, usando el idServicio como idMaquina
        $etapaArquitectura = 'Producción'; // Etapa por defecto
        $tipoArquitectura = 'Monolítica'; // Tipo por defecto (ajústalo según el formulario)

        $queryArquitectura = "INSERT INTO ARQUITECTURA (etapa, tipo, idMaquina) 
                              VALUES (?, ?, ?)";
        $stmtArquitectura = mysqli_prepare($con, $queryArquitectura);
        mysqli_stmt_bind_param($stmtArquitectura, 'ssi', $etapaArquitectura, $tipoArquitectura, $idServicio); // Usar idServicio como idMaquina

        if (mysqli_stmt_execute($stmtArquitectura)) {
            //echo "Arquitectura asociada correctamente a la máquina virtual.<br>";
        } else {
            die("Error al guardar la arquitectura: " . mysqli_error($con));
        }

        // Insertar en otras tablas relacionadas como DISCO_DURO, CPU, RAM, etc.
        // Ejemplo de insert en DISCO_DURO:
        $etapaDiscoDuro = 'Producción'; // Etapa por defecto
        $tipoDiscoDuro = $_POST['disco_duro']; // Tipo de disco duro desde el formulario

        $queryDiscoDuro = "INSERT INTO DISCO_DURO (numeroSerie, etapa, tipo, idMaquina) 
                           VALUES (?, ?, ?, ?)";
        $stmtDiscoDuro = mysqli_prepare($con, $queryDiscoDuro);
        if(mysqli_stmt_bind_param($stmtDiscoDuro, 'sssi', $numSerieRed, $etapaDiscoDuro, $tipoDiscoDuro, $idServicio)){

        } else{
            echo '<div style="background-color: red; color: white; padding: 20px; text-align: center; border-radius: 5px;">
            <h2>¡Numero de serie ya existente!</h2>
            <p>Inserta un numero diferente.</p>
            <a href="index.php" style="color: white; padding: 10px 20px; background-color: #007BFF; text-decoration: none; border-radius: 5px;">Volver al Inicio</a>
          </div>';// Usar idServicio como idMaquina
        }

        if (mysqli_stmt_execute($stmtDiscoDuro)) {
            //echo "Disco Duro asociado correctamente a la máquina virtual.<br>";
            echo '<div style="background-color: green; color: white; padding: 20px; text-align: center; border-radius: 5px;">
            <h2>¡Configuración guardada correctamente!</h2>
            <p>La configuración se ha guardado con éxito.</p>
            <a href="index.php" style="color: white; padding: 10px 20px; background-color: #007BFF; text-decoration: none; border-radius: 5px;">Volver al Inicio</a>
          </div>';
        } else {
            die("Error al guardar el disco duro: " . mysqli_error($con));
        }

        // Continúa con otros inserts como RAM, CPU, etc.

        break;

    case 'Servidor HTTP':

        //primero guardamos el servicio
        $fechaModificacion = date('Y-m-d H:i:s');
        $precio = 100.00; // Puedes ajustar el precio según tu lógica
        $etapa = 'Producción'; // Etapa por defecto

        if (!isset($_SESSION['email'])) {
            die("Error: Usuario no autenticado. Por favor, inicie sesión.");
        }

        $correoElectronicoCliente = $_SESSION['email'];
        $idTipo = 2; // Tipo específico para Máquina Virtual

        $queryServicio = "INSERT INTO SERVICIO (fechaModificacion, precio, etapa, correoElectronicoCliente, idTipo) 
                          VALUES (?, ?, ?, ?, ?)";
        $stmtServicio = mysqli_prepare($con, $queryServicio);
        mysqli_stmt_bind_param($stmtServicio, 'sdssi', $fechaModificacion, $precio, $etapa, $correoElectronicoCliente, $idTipo);

        if (mysqli_stmt_execute($stmtServicio)) {
            // Obtener el idServicio generado automáticamente
            $idServicio = mysqli_insert_id($con); // idServicio = idMaquina
           // echo "Servicio guardado correctamente. ID del servicio: $idServicio.<br>";
        } else {
            die("Error al guardar el servicio: " . mysqli_error($con));
        }

        //guardamos en la tabla servidorHTTP


// Paso 2: Verificar si la combinación de major, minor, patch existe en la tabla VERSION
$major = intval($_POST['major']);
$minor = intval($_POST['minor']);
$patch = intval($_POST['patch']);

// Verificar si la combinación de versión existe
$queryVersion = "SELECT major, minor, patch FROM VERSION WHERE major = ? AND minor = ? AND patch = ?";
$stmtVersion = mysqli_prepare($con, $queryVersion);
mysqli_stmt_bind_param($stmtVersion, 'iii', $major, $minor, $patch);
mysqli_stmt_execute($stmtVersion);
mysqli_stmt_store_result($stmtVersion);

// Si no existe la versión, insertarla en la tabla VERSION
if (mysqli_stmt_num_rows($stmtVersion) == 0) {
    // Insertar la nueva versión
    $queryInsertVersion = "INSERT INTO VERSION (major, minor, patch) VALUES (?, ?, ?)";
    $stmtInsertVersion = mysqli_prepare($con, $queryInsertVersion);
    mysqli_stmt_bind_param($stmtInsertVersion, 'iii', $major, $minor, $patch);
    
    if (mysqli_stmt_execute($stmtInsertVersion)) {
        //echo "Versión insertada correctamente en la tabla VERSION.<br>";
        echo '<div style="background-color: green; color: white; padding: 20px; text-align: center; border-radius: 5px;">
        <h2>¡Configuración guardada correctamente!</h2>
        <p>La configuración se ha guardado con éxito.</p>
        <a href="index.php" style="color: white; padding: 10px 20px; background-color: #007BFF; text-decoration: none; border-radius: 5px;">Volver al Inicio</a>
      </div>';

    } else {
        die("Error al insertar la versión en la tabla VERSION: " . mysqli_error($con));
    }
}

// Continúa con el resto del código para el procesamiento...


// Paso 3: Insertar en la tabla SERVIDOR_HTTP utilizando idServicio como idServidor
$puerto1 = intval($_POST['puerto1']);
$puerto2 = intval($_POST['puerto2']);
$directorioRaiz = $_POST['directorio_raiz'];
$estado = 'Activo'; // Puedes cambiarlo según el formulario
$fechaCreacion = date('Y-m-d');
$ipPublica = $_POST['ipPublica']; // Si la tienes en el formulario
$ipPrivada = $_POST['ipPrivada']; // Si la tienes en el formulario
$protocoloTransporte = $_POST['protocoloTransporte']; // Protocolo de transporte desde el formulario
$rutaConfiguracion = $_POST['rutaConfiguracion']; // Ruta de configuración desde el formulario

$queryServidorHttp = "INSERT INTO SERVIDOR_HTTP (idServidor, puerto1, puerto2, directorioRaiz, estado, fechaCreacion, ipPublica, ipPrivada, protocoloTransporte, rutaConfiguracion, major, minor, patch) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmtServidorHttp = mysqli_prepare($con, $queryServidorHttp);

// Bind parameters para la consulta
mysqli_stmt_bind_param($stmtServidorHttp, 'iiisssssssiii', $idServicio, $puerto1, $puerto2, $directorioRaiz, $estado, $fechaCreacion, $ipPublica, $ipPrivada, $protocoloTransporte, $rutaConfiguracion, $major, $minor, $patch);

// Ejecutar la consulta
if (mysqli_stmt_execute($stmtServidorHttp)) {
    //echo "Servidor HTTP asociado correctamente al servicio. ID del servidor: $idServicio.<br>";

    echo '<div style="background-color: green; color: white; padding: 20px; text-align: center; border-radius: 5px;">
    <h2>¡Configuración guardada correctamente!</h2>
    <p>La configuración se ha guardado con éxito.</p>
    <a href="index.php" style="color: white; padding: 10px 20px; background-color: #007BFF; text-decoration: none; border-radius: 5px;">Volver al Inicio</a>
  </div>';
} else {
    die("Error al guardar el servidor HTTP: " . mysqli_error($con));
}



        break;

    case 'Base de datos MySQL':

        
// Primero guardamos el servicio
$fechaModificacion = date('Y-m-d H:i:s');
$precio = 100.00; // Puedes ajustar el precio según tu lógica
$etapa = 'Producción'; // Etapa por defecto

if (!isset($_SESSION['email'])) {
    die("Error: Usuario no autenticado. Por favor, inicie sesión.");
}

$correoElectronicoCliente = $_SESSION['email'];
$idTipo = 3; // Tipo específico

$queryServicio = "INSERT INTO SERVICIO (fechaModificacion, precio, etapa, correoElectronicoCliente, idTipo) 
                  VALUES (?, ?, ?, ?, ?)";
$stmtServicio = mysqli_prepare($con, $queryServicio);
mysqli_stmt_bind_param($stmtServicio, 'sdssi', $fechaModificacion, $precio, $etapa, $correoElectronicoCliente, $idTipo);

if (mysqli_stmt_execute($stmtServicio)) {
    // Obtener el idServicio generado automáticamente
    $idServicio = mysqli_insert_id($con); // idServicio = idMaquina
    //echo "Servicio guardado correctamente. ID del servicio: $idServicio.<br>";
} else {
    die("Error al guardar el servicio: " . mysqli_error($con));
}

// Recoger los datos del formulario
$ipCliente = $_POST['ipCliente'];
$almacenamiento = $_POST['almacenamiento'];
$PID = $_POST['PID'];
$puerto = $_POST['puerto'];
$ipPublica = $_POST['ipPublica'];
$ipPrivada = $_POST['ipPrivada'];
$protocoloTransporte = $_POST['protocoloTransporte'];
$protocoloAplicacion = $_POST['protocoloAplicacion'];
$rutaConfiguracion = $_POST['rutaConfiguracion'];

$major = $_POST['major'];
$minor = $_POST['minor'];
$patch = $_POST['patch'];

// Los valores de "idPlan" se autogeneran, no se pasan desde el formulario
$modo = $_POST['modo'];
$motor = $_POST['motor'];
$tamano_buffer = $_POST['tamano_buffer'];
$soporte_transacciones = $_POST['soporte_transacciones'];
$recuperacion = isset($_POST['recuperacion']) ? $_POST['recuperacion'] : null; // Solo se incluye si el motor es MyISAM

// Comenzamos la transacción
$con->begin_transaction();

try {
    // Paso 1: Verificar si la combinación de major, minor, patch existe en la tabla VERSION
    $queryVersion = "SELECT major, minor, patch FROM VERSION WHERE major = ? AND minor = ? AND patch = ?";
    $stmtVersion = mysqli_prepare($con, $queryVersion);
    mysqli_stmt_bind_param($stmtVersion, 'iii', $major, $minor, $patch);
    mysqli_stmt_execute($stmtVersion);
    mysqli_stmt_store_result($stmtVersion);

    // Si la versión no existe, insertarla en la tabla VERSION
    if (mysqli_stmt_num_rows($stmtVersion) == 0) {
        $queryInsertVersion = "INSERT INTO VERSION (major, minor, patch) VALUES (?, ?, ?)";
        $stmtInsertVersion = mysqli_prepare($con, $queryInsertVersion);
        mysqli_stmt_bind_param($stmtInsertVersion, 'iii', $major, $minor, $patch);

        if (mysqli_stmt_execute($stmtInsertVersion)) {
            //echo "Versión insertada correctamente en la tabla VERSION.<br>";
        } else {
            die("Error al insertar la versión en la tabla VERSION: " . mysqli_error($con));
        }
    } else {
        //echo "La versión ya existe en la tabla VERSION.<br>";
    }

    // Paso 2: Insertar en la tabla BASE_DE_DATOS (usando idServicio como idBD)
    $sql_bd = "INSERT INTO BASE_DE_DATOS (idBD, ipCliente, almacenamiento, PID, puerto, ipPublica, ipPrivada, protocoloTransporte, protocoloAplicacion, rutaConfiguracion, major, minor, patch) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Usamos idServicio como idBD en BASE_DE_DATOS
    $stmt_bd = $con->prepare($sql_bd);
    $stmt_bd->bind_param("isiiiissssiii", $idServicio, $ipCliente, $almacenamiento, $PID, $puerto, $ipPublica, $ipPrivada, $protocoloTransporte, $protocoloAplicacion, $rutaConfiguracion, $major, $minor, $patch);
    if ($stmt_bd->execute()) {
        //echo "BASE_DE_DATOS insertada correctamente. ID de BD: " . $idServicio . "<br>";
    } else {
        die("Error al insertar en BASE_DE_DATOS: " . mysqli_error($con));
    }

    // Ahora $idServicio se usará como idBD correctamente
    $idBD = $idServicio;
    //echo "ID de BD obtenido: " . $idBD . "<br>";

    // Paso 3: Insertar en la tabla MYSQL
    $sql_mysql = "INSERT INTO MYSQL (idBDMySQL, modo, idMotor) VALUES (?, ?, ?)";
    $idMotor = ($motor == 'innodb') ? 1 : 2; // Ajustar dependiendo de tus valores en la tabla MOTOR

    $stmt_mysql = $con->prepare($sql_mysql);
    $stmt_mysql->bind_param("isi", $idBD, $modo, $idMotor);
    if ($stmt_mysql->execute()) {
        //echo "MYSQL insertado correctamente.<br>";
    } else {
        die("Error al insertar en MYSQL: " . mysqli_error($con));
    }

    // Confirmar la transacción
    $con->commit();

    echo '<div style="background-color: green; color: white; padding: 20px; text-align: center; border-radius: 5px;">
    <h2>¡Configuración guardada correctamente!</h2>
    <p>La configuración se ha guardado con éxito.</p>
    <a href="index.php" style="color: white; padding: 10px 20px; background-color: #007BFF; text-decoration: none; border-radius: 5px;">Volver al Inicio</a>
  </div>';

    //echo "La configuración se ha guardado correctamente.";
    // header("Location: pagina_de_exito.php"); // Si deseas redirigir a otra página
} catch (Exception $e) {
    // Si ocurre algún error, deshacer la transacción
    $con->rollback();
    echo "Error: " . $e->getMessage();
}

break;

    case 'Base de datos PostgreSQL':

// Definir las variables con valores predeterminados
$fechaModificacion = date('Y-m-d H:i:s');
$precio = 100.00; // Puedes ajustar el precio según tu lógica
$etapa = 'Producción'; // Etapa por defecto
$correoElectronicoCliente = $_SESSION['email'];
$idTipo = 3; // Tipo específico (cambiar según sea necesario)

// Iniciar la transacción
$con->begin_transaction();

try {
    // Paso 1: Insertar en la tabla SERVICIO
    $queryServicio = "INSERT INTO SERVICIO (fechaModificacion, precio, etapa, correoElectronicoCliente, idTipo) 
                      VALUES (?, ?, ?, ?, ?)";
    $stmtServicio = $con->prepare($queryServicio);
    if ($stmtServicio === false) {
        die("Error al preparar la consulta de servicio: " . $con->error);
    }

    $stmtServicio->bind_param('sdssi', $fechaModificacion, $precio, $etapa, $correoElectronicoCliente, $idTipo);

    if ($stmtServicio->execute()) {
        $idServicio = $con->insert_id; // Obtener el idServicio generado automáticamente
        //echo "Servicio guardado correctamente. ID del servicio: $idServicio.<br>";
    } else {
        die("Error al guardar el servicio: " . $stmtServicio->error);
    }

    // Paso 2: Recoger los datos del formulario y validarlos
    $ipCliente = isset($_POST['ipCliente']) ? $_POST['ipCliente'] : null;
    $almacenamiento = isset($_POST['almacenamiento']) ? $_POST['almacenamiento'] : null;
    $PID = isset($_POST['PID']) ? $_POST['PID'] : null;
    $puerto = isset($_POST['puerto']) ? $_POST['puerto'] : null;
    $ipPublica = isset($_POST['ipPublica']) ? $_POST['ipPublica'] : null;
    $ipPrivada = isset($_POST['ipPrivada']) ? $_POST['ipPrivada'] : null;
    $protocoloTransporte = isset($_POST['protocoloTransporte']) ? $_POST['protocoloTransporte'] : null;
    $protocoloAplicacion = isset($_POST['protocoloAplicacion']) ? $_POST['protocoloAplicacion'] : null;
    $rutaConfiguracion = isset($_POST['rutaConfiguracion']) ? $_POST['rutaConfiguracion'] : null;

    $major = isset($_POST['major']) ? $_POST['major'] : null;
    $minor = isset($_POST['minor']) ? $_POST['minor'] : null;
    $patch = isset($_POST['patch']) ? $_POST['patch'] : null;

    // Validar las extensiones (múltiples opciones)
    if (isset($_POST['extension'])) {
        $extension = implode(",", $_POST['extension']); // Unir las extensiones seleccionadas
    } else {
        $extension = ''; // Si no se seleccionaron extensiones
    }

    $encoding = isset($_POST['encoding']) ? $_POST['encoding'] : null;
    $conexionesMaximas = 100;

    // Paso 3: Insertar en la tabla VERSION si no existe la combinación de major, minor, patch
    $queryVersion = "SELECT major, minor, patch FROM VERSION WHERE major = ? AND minor = ? AND patch = ?";
    $stmtVersion = $con->prepare($queryVersion);
    if ($stmtVersion === false) {
        die("Error al preparar la consulta de versión: " . $con->error);
    }

    $stmtVersion->bind_param('iii', $major, $minor, $patch);
    $stmtVersion->execute();
    $stmtVersion->store_result();

    // Si la versión no existe, insertarla en la tabla VERSION
    if ($stmtVersion->num_rows == 0) {
        $queryInsertVersion = "INSERT INTO VERSION (major, minor, patch) VALUES (?, ?, ?)";
        $stmtInsertVersion = $con->prepare($queryInsertVersion);
        if ($stmtInsertVersion === false) {
            die("Error al preparar la consulta de inserción de versión: " . $con->error);
        }

        $stmtInsertVersion->bind_param('iii', $major, $minor, $patch);
        if ($stmtInsertVersion->execute()) {
            //echo "Versión insertada correctamente en la tabla VERSION.<br>";
        } else {
            die("Error al insertar la versión en la tabla VERSION: " . $stmtInsertVersion->error);
        }
    } else {
        //echo "La versión ya existe en la tabla VERSION.<br>";
    }

    // Paso 4: Insertar en la tabla BASE_DE_DATOS (usando idServicio como idBD)
    $sql_bd = "INSERT INTO BASE_DE_DATOS (idBD, ipCliente, almacenamiento, PID, puerto, ipPublica, ipPrivada, protocoloTransporte, protocoloAplicacion, rutaConfiguracion, major, minor, patch) 
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt_bd = $con->prepare($sql_bd);
    if ($stmt_bd === false) {
        die("Error al preparar la consulta de BASE_DE_DATOS: " . $con->error);
    }

    $stmt_bd->bind_param("isiiiissssiii", $idServicio, $ipCliente, $almacenamiento, $PID, $puerto, $ipPublica, $ipPrivada, $protocoloTransporte, $protocoloAplicacion, $rutaConfiguracion, $major, $minor, $patch);
    if ($stmt_bd->execute()) {
        //echo "BASE_DE_DATOS insertada correctamente. ID de BD: $idServicio<br>";
    } else {
        die("Error al insertar en BASE_DE_DATOS: " . $stmt_bd->error);
    }

    // Paso 5: Insertar en la tabla POSTGRESQL
    $sql_postgresql = "INSERT INTO POSTGRESQL (idBDPostgreSQL, encoding, conexionesMaximas, extension) 
                       VALUES (?, ?, ?, ?)";
    $stmt_postgresql = $con->prepare($sql_postgresql);
    if ($stmt_postgresql === false) {
        die("Error al preparar la consulta de POSTGRESQL: " . $con->error);
    }

    $stmt_postgresql->bind_param("isis", $idServicio, $encoding, $conexionesMaximas, $extension);
    if ($stmt_postgresql->execute()) {
        //echo "POSTGRESQL insertado correctamente.<br>";
    } else {
        die("Error al insertar en POSTGRESQL: " . $stmt_postgresql->error);
    }

    // Confirmar la transacción
    $con->commit();
    //echo "La configuración se ha guardado correctamente.";
    // header("Location: pagina_de_exito.php"); // Si deseas redirigir a otra página

    echo '<div style="background-color: green; color: white; padding: 20px; text-align: center; border-radius: 5px;">
    <h2>¡Configuración guardada correctamente!</h2>
    <p>La configuración se ha guardado con éxito.</p>
    <a href="index.php" style="color: white; padding: 10px 20px; background-color: #007BFF; text-decoration: none; border-radius: 5px;">Volver al Inicio</a>
  </div>';

} catch (Exception $e) {
    // Si ocurre un error, deshacer la transacción
    $con->rollback();
    echo "Error: " . $e->getMessage();
}

        break;





    default:
        echo "Error: Tipo de servicio no reconocido.";
        break;

}


// Cerrar la conexión
mysqli_close($con);
?>


