DROP DATABASE IF EXISTS TOT_CLOUD;
CREATE DATABASE TOT_CLOUD;
USE TOT_CLOUD;

START TRANSACTION;

CREATE TABLE TAULA_RUTA (
  idTaulaRuta INT AUTO_INCREMENT PRIMARY KEY,
  descripcio TEXT
);

CREATE TABLE RUTA (
  idRuta INT AUTO_INCREMENT PRIMARY KEY,
  destinationCIDR VARCHAR(64),
  tipusDesti VARCHAR(64),
  estat VARCHAR(64),
  idTaulaRuta INT,
  FOREIGN KEY (idTaulaRuta) REFERENCES TAULA_RUTA(idTaulaRuta)
);

CREATE TABLE SUBNET (
  idSubnet INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(128),
  cidrBlock VARCHAR(64),
  tipus VARCHAR(64),
  descripcio TEXT,
  idTaulaRuta INT,
  FOREIGN KEY (idTaulaRuta) REFERENCES TAULA_RUTA(idTaulaRuta)
);

CREATE TABLE NATGW (
  idNatGW INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(128),
  status VARCHAR(64),
  idSubnet INT,
  FOREIGN KEY (idSubnet) REFERENCES SUBNET(idSubnet)
);

CREATE TABLE INTERNET_GW (
  idInternetGW INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(128),
  status VARCHAR(64)
);

CREATE TABLE ENDPOINT (
  idEndpoint INT AUTO_INCREMENT PRIMARY KEY,
  endpointURL VARCHAR(256),
  descripcio TEXT,
  tipusAcces VARCHAR(64)
);

CREATE TABLE ORGANITZACIO(
  idOrganitzacio INT AUTO_INCREMENT PRIMARY KEY,
  direccio VARCHAR(32), 
  nomOrganitzacio VARCHAR(16)
);

CREATE TABLE USUARI (
  idUsuari INT AUTO_INCREMENT PRIMARY KEY ,
  correuElectronic VARCHAR(128),
  contrasenya VARCHAR(60),
  nom VARCHAR(128),
  cognom1 VARCHAR(128),
  cognom2 VARCHAR(128),
  numeroTelefon VARCHAR(32),
   -- tipo enumerado para tipos de usuario
  tipusUsuari ENUM('Personal', 'Client', 'Administrador') NOT NULL,
  idOrganitzacio INT,
  FOREIGN KEY (idOrganitzacio) REFERENCES ORGANITZACIO(idOrganitzacio)
);

CREATE TABLE VPC (
  idVPC INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(128),
  supportIPv4 BOOLEAN,
  supportIPv6 BOOLEAN,
  cidrBlock VARCHAR(64),
  regio VARCHAR(64),
  dataCreacio DATETIME,
  dataModificacio DATETIME,
  status VARCHAR(64),
  idRuta INT,
  idInternetGW INT,
  idUsuari INT,
  idEndpoint INT,
  FOREIGN KEY (idRuta) REFERENCES RUTA(idRuta),
  FOREIGN KEY (idInternetGW) REFERENCES INTERNET_GW(idInternetGW),
  FOREIGN KEY (idUsuari) REFERENCES USUARI(idUsuari),
  FOREIGN KEY (idEndpoint) REFERENCES ENDPOINT(idEndpoint)
);

  CREATE TABLE GRUP_SEGURETAT (
    idGrupSeguretat INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(128),
    descripcio TEXT,
    idVPC INT,
    FOREIGN KEY (idVPC) REFERENCES VPC(idVPC)
  );

CREATE TABLE REGLA_SEGURETAT (
  idReglaSeguretat INT AUTO_INCREMENT PRIMARY KEY,
  direccio VARCHAR(64),
  protocol VARCHAR(64),
  rangPorts VARCHAR(64),
  origenDesti VARCHAR(64),
  descripcio TEXT,
  idGrupSeguretat INT,
  FOREIGN KEY (idGrupSeguretat) REFERENCES GRUP_SEGURETAT(idGrupSeguretat)
);

CREATE TABLE INFRAESTRUCTURA_COMPUTACIO (
  idInfraestructura INT AUTO_INCREMENT PRIMARY KEY,
  idServeiConfig INT,
  idMaquinaVirtual INT,
  idUsuari INT,
  FOREIGN KEY (idUsuari) REFERENCES USUARI(idUsuari)
);

-- Ahora, agregamos etapa ENUM en SERVEI_CATALEG
CREATE TABLE SERVEI_CATALEG (
  idServeiCataleg INT AUTO_INCREMENT PRIMARY KEY,
  NomServei VARCHAR(64) NOT NULL,
  DescServei VARCHAR(256),
  tipusServei ENUM('PaaS','SaaS') NOT NULL,
  etapa ENUM('Desarrollo','Pruebas','Preproducción','Producción') NOT NULL
);

CREATE TABLE SERVEI_CONFIGURACIO (
  idServeiConfig INT AUTO_INCREMENT PRIMARY KEY,
  dataCreacio DATETIME,
  dataModificacio DATETIME,
  idEndpoint INT,
  idServeiCatalog INT,
  idVPC INT,
  idInfraestructura INT,
  FOREIGN KEY (idEndpoint) REFERENCES ENDPOINT(idEndpoint),
  FOREIGN KEY (idServeiCatalog) REFERENCES SERVEI_CATALEG(idServeiCataleg),
  FOREIGN KEY (idVPC) REFERENCES VPC(idVPC),
  FOREIGN KEY (idInfraestructura) REFERENCES INFRAESTRUCTURA_COMPUTACIO(idInfraestructura)
);

CREATE TABLE MAQUINA_VIRTUAL (
  AdrecaIP VARCHAR(64) PRIMARY KEY,
  Nom VARCHAR(128),
  descripcio TEXT,
  dataCreacio DATETIME,
  dataModificacio DATETIME,
  idEndpoint INT,
  idVPC INT,
  idUsuari INT,
  idInfraestructura INT,
  FOREIGN KEY (idEndpoint) REFERENCES ENDPOINT(idEndpoint),
  FOREIGN KEY (idVPC) REFERENCES VPC(idVPC),
  FOREIGN KEY (idUsuari) REFERENCES USUARI(idUsuari),
  FOREIGN KEY (idInfraestructura) REFERENCES INFRAESTRUCTURA_COMPUTACIO(idInfraestructura)
);

-- Eliminamos la tabla ETAPA original y pasamos etapa a las tablas solicitadas

CREATE TABLE ARQUITECTURA (
  númeroSerie VARCHAR(64) PRIMARY KEY,
  model VARCHAR(128),
  tipus VARCHAR(64),
  etapa ENUM('Desarrollo','Pruebas','Preproducción','Producción') NOT NULL,
  AdrecaIP VARCHAR(64),
  idUsuari INT,
  FOREIGN KEY (idUsuari) REFERENCES USUARI(idUsuari),
  FOREIGN KEY (AdrecaIP) REFERENCES MAQUINA_VIRTUAL(AdrecaIP)
);

CREATE TABLE COMPONENT_DE_XARXA (
  númeroSerie VARCHAR(64) PRIMARY KEY,
  model VARCHAR(128),
  tipus VARCHAR(64),
  etapa ENUM('Desarrollo','Pruebas','Preproducción','Producción') NOT NULL,
  AdrecaIP VARCHAR(64),
  idUsuari INT,
  FOREIGN KEY (idUsuari) REFERENCES USUARI(idUsuari),
  FOREIGN KEY (AdrecaIP) REFERENCES MAQUINA_VIRTUAL(AdrecaIP)
);

CREATE TABLE CPU (
  númeroSerie VARCHAR(64) PRIMARY KEY,
  model VARCHAR(128),
  nuclis INT,
  generacio VARCHAR(64),
  etapa ENUM('Desarrollo','Pruebas','Preproducción','Producción') NOT NULL,
  AdrecaIP VARCHAR(64),
  idUsuari INT,
  FOREIGN KEY (idUsuari) REFERENCES USUARI(idUsuari),
  FOREIGN KEY (AdrecaIP) REFERENCES MAQUINA_VIRTUAL(AdrecaIP)
);

CREATE TABLE RAM (
  númeroSerie VARCHAR(64) PRIMARY KEY,
  model VARCHAR(128),
  capacitat VARCHAR(64),
  generacio VARCHAR(64),
  etapa ENUM('Desarrollo','Pruebas','Preproducción','Producción') NOT NULL,
  AdrecaIP VARCHAR(64),
  idUsuari INT,
  FOREIGN KEY (idUsuari) REFERENCES USUARI(idUsuari),
  FOREIGN KEY (AdrecaIP) REFERENCES MAQUINA_VIRTUAL(AdrecaIP)
);

CREATE TABLE DISC_DUR (
  númeroSerie VARCHAR(64) PRIMARY KEY,
  model VARCHAR(128),
  tipus VARCHAR(64),
  capacitat VARCHAR(64),
  etapa ENUM('Desarrollo','Pruebas','Preproducción','Producción') NOT NULL,
  AdrecaIP VARCHAR(64),
  idUsuari INT,
  FOREIGN KEY (idUsuari) REFERENCES USUARI(idUsuari),
  FOREIGN KEY (AdrecaIP) REFERENCES MAQUINA_VIRTUAL(AdrecaIP)
);

CREATE TABLE SERVEI_CONFIGURACIO_COPIA (
  idServeiCopia INT AUTO_INCREMENT PRIMARY KEY,
  dataCreacio DATETIME,
  dataModificacio DATETIME,
  dataCopia DATE,
  horaCopia TIME
);

CREATE TABLE INFRAESTRUCTURA_COPIA (
  idInfraestructuraCopia INT AUTO_INCREMENT PRIMARY KEY,
  dataCopia DATE,
  horaCopia TIME
);

CREATE TABLE MAQUINA_VIRTUAL_COPIA (
  AdrecaIPCopia VARCHAR(64) PRIMARY KEY,
  Nom VARCHAR(128),
  descripcio TEXT,
  dataCreacio DATETIME,
  dataModificacio DATETIME,
  dataCopia DATE,
  horaCopia TIME
);

CREATE TABLE VPC_COPIA (
  idVPCCopia INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(128),
  supportIPv4 BOOLEAN,
  supportIPv6 BOOLEAN,
  cidrBlock VARCHAR(64),
  regio VARCHAR(64),
  dataCreacio DATETIME,
  dataModificacio DATETIME,
  status VARCHAR(64),
  dataCopia DATE,
  horaCopia TIME
);

CREATE TABLE MONITORATGE (
  idMonitoratge INT AUTO_INCREMENT PRIMARY KEY,
  metrica1 FLOAT,
  metrica2 FLOAT,
  metrica3 FLOAT,
  timeStamp DATETIME,
  estat VARCHAR(64),
  idServeiConfig INT,
  FOREIGN KEY (idServeiConfig) REFERENCES SERVEI_CONFIGURACIO(idServeiConfig)
);

CREATE TABLE BASE_DE_DADES (
  idBaseDeDades INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(128),
  tipusBD VARCHAR(64),
  backupAutomatic BOOLEAN,
  tamanyMax INT,
  idServeiConfig INT,
  FOREIGN KEY (idServeiConfig) REFERENCES SERVEI_CONFIGURACIO(idServeiConfig)
);

CREATE TABLE ODDO (
  idODDO INT AUTO_INCREMENT PRIMARY KEY,
  modulsActius VARCHAR(256),
  idServeiConfig INT,
  FOREIGN KEY (idServeiConfig) REFERENCES SERVEI_CONFIGURACIO(idServeiConfig)
);

CREATE TABLE MATOMO (
  idMatomo INT AUTO_INCREMENT PRIMARY KEY,
  dominiMonitoritzat VARCHAR(128),
  politicaRetencio VARCHAR(128),
  idServeiConfig INT,
  FOREIGN KEY (idServeiConfig) REFERENCES SERVEI_CONFIGURACIO(idServeiConfig)
);

CREATE TABLE MOODLE (
  idMoodle INT AUTO_INCREMENT PRIMARY KEY,
  idioma VARCHAR(64),
  idServeiConfig INT,
  FOREIGN KEY (idServeiConfig) REFERENCES SERVEI_CONFIGURACIO(idServeiConfig)
);

CREATE TABLE APLICACIO (
  idApp INT AUTO_INCREMENT PRIMARY KEY,
  idioma VARCHAR(64),
  idServeiConfig INT,
  FOREIGN KEY (idServeiConfig) REFERENCES SERVEI_CONFIGURACIO(idServeiConfig)
);

CREATE TABLE PLUGIN (
  idPlugin INT AUTO_INCREMENT PRIMARY KEY,
  nomPlugin VARCHAR(128),
  idApp INT,
  FOREIGN KEY (idApp) REFERENCES APLICACIO(idApp)
);

CREATE TABLE GRUP (
  idGrup INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(128),
  descripcio TEXT
);

CREATE TABLE PRIVILEGI (
  idPrivilegi INT AUTO_INCREMENT PRIMARY KEY,
  nom VARCHAR(128)
);

CREATE TABLE GRUP_SEGURETAT_PER_BASE_DADES (
  idGrupSeguretat INT,
  idBaseDeDades INT,
  PRIMARY KEY (idGrupSeguretat, idBaseDeDades),
  FOREIGN KEY (idGrupSeguretat) REFERENCES GRUP_SEGURETAT(idGrupSeguretat),
  FOREIGN KEY (idBaseDeDades) REFERENCES BASE_DE_DADES(idBaseDeDades)
);

CREATE TABLE USUARI_PER_GRUP (
  idUsuari INT,
  idGrup INT,
  PRIMARY KEY (idUsuari, idGrup),
  FOREIGN KEY (idUsuari) REFERENCES USUARI(idUsuari),
  FOREIGN KEY (idGrup) REFERENCES GRUP(idGrup)
);

CREATE TABLE PRIVILEGI_PER_GRUP (
  idPrivilegi INT,
  idGrup INT,
  PRIMARY KEY (idPrivilegi, idGrup),
  FOREIGN KEY (idPrivilegi) REFERENCES PRIVILEGI(idPrivilegi),
  FOREIGN KEY (idGrup) REFERENCES GRUP(idGrup)
);

CREATE TABLE SERVICIO_COPIA_SERVICIO (
  idServeiConfig INT,
  idServeiCopia INT,
  PRIMARY KEY (idServeiConfig, idServeiCopia),
  FOREIGN KEY (idServeiConfig) REFERENCES SERVEI_CONFIGURACIO(idServeiConfig),
  FOREIGN KEY (idServeiCopia) REFERENCES SERVEI_CONFIGURACIO_COPIA(idServeiCopia)
);

CREATE TABLE MAQUINA_VIRTUAL_COPIA_MAQUINA_VIRTUAL (
  AdrecaIP VARCHAR(64),
  AdrecaIPCopia VARCHAR(64),
  PRIMARY KEY (AdrecaIP, AdrecaIPCopia),
  FOREIGN KEY (AdrecaIP) REFERENCES MAQUINA_VIRTUAL(AdrecaIP),
  FOREIGN KEY (AdrecaIPCopia) REFERENCES MAQUINA_VIRTUAL_COPIA(AdrecaIPCopia)
);

CREATE TABLE VPC_COPIAVPC (
  idVPC INT,
  idVPCCopia INT,
  PRIMARY KEY (idVPC, idVPCCopia),
  FOREIGN KEY (idVPC) REFERENCES VPC(idVPC),
  FOREIGN KEY (idVPCCopia) REFERENCES VPC_COPIA(idVPCCopia)
);

CREATE TABLE INFRAESTRUCTURA_COPIA_INFRAESTRUCTURA (
  idInfraestructura INT,
  idInfraestructuraCopia INT,
  PRIMARY KEY (idInfraestructura, idInfraestructuraCopia),
  FOREIGN KEY (idInfraestructura) REFERENCES INFRAESTRUCTURA_COMPUTACIO(idInfraestructura),
  FOREIGN KEY (idInfraestructuraCopia) REFERENCES INFRAESTRUCTURA_COPIA(idInfraestructuraCopia)
);
COMMIT;

ROLLBACK;
