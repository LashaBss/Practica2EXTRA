USE TOT_CLOUD;

START TRANSACTION;

-- Insertar usuarios
INSERT INTO USUARIO(correoElectronico, contraseña, nombre, primerApellido, segundoApellido, numeroTelefono, nombreGrupo)
VALUES ('juan@gmail.com', 'password123', 'Juan', 'Perez', NULL, '1234567890', 'Administrador');

INSERT INTO USUARIO(correoElectronico, contraseña, nombre, primerApellido, segundoApellido, numeroTelefono, nombreGrupo)
VALUES ('pepe@gmail.com', 'password123', 'Pepe', 'Perez', NULL, '1234567890', 'Cliente');

-- Insertar personal
INSERT INTO PERSONAL (correoElectronicoPersonal) VALUES ('juan@gmail.com');

-- Insertar cliente
INSERT INTO CLIENTE(correoElectronicoCliente) VALUES ('pepe@gmail.com');

-- Insertar versiones
INSERT INTO VERSION(major, minor, patch) VALUES (1, 0, 0);
INSERT INTO VERSION(major, minor, patch) VALUES (20, 4, 1);

SET @descripcion_tipo_1 = 'Contrata un entorno virtualizado que emula un sistema informático físico, ' ||
                          'permitiendo ejecutar sistemas operativos y aplicaciones independientes en hardware compartido. ' ||
                          'Es ideal para entornos de desarrollo, pruebas o producción.';
SET @descripcion_tipo_2 = 'Contrata una aplicación que maneja solicitudes y respuestas en el protocolo HTTP. ' ||
                          'Se utiliza para alojar y servir páginas web o aplicaciones accesibles a través de Internet o intranets.';
SET @descripcion_tipo_3 = 'Un servicio de base de datos relacional basado en MySQL, que ofrece almacenamiento y ' ||
                          'recuperación de datos estructurados. Ideal para aplicaciones que requieren rendimiento y escalabilidad.';
SET @descripcion_tipo_4 = 'Un sistema de base de datos relacional avanzada que soporta extensiones, ' ||
                          'tipos de datos complejos y operaciones analíticas. Ideal para aplicaciones empresariales y analítica de datos.';

-- Insertar tipo de servicio
INSERT INTO TIPO_SERVICIO(nombreTipoServicio, descripcion, tipologia)
VALUES ('Máquina Virtual',  @descripcion_tipo_1, 'PaaS');
INSERT INTO TIPO_SERVICIO(nombreTipoServicio, descripcion, tipologia)
VALUES ('Servidor HTTP', @descripcion_tipo_2, 'PaaS');
INSERT INTO TIPO_SERVICIO(nombreTipoServicio, descripcion, tipologia)
VALUES ('Base de datos MySQL', @descripcion_tipo_3, 'SaaS');
INSERT INTO TIPO_SERVICIO(nombreTipoServicio, descripcion, tipologia)
VALUES ('Base de datos PostgreSQL', @descripcion_tipo_4, 'SaaS');

-- Insertar servicio 
INSERT INTO SERVICIO(fechaModificacion, etapa, correoElectronicoCliente, nombreTipoServicio)
VALUES ('2024-01-01', 'Producción', 'pepe@gmail.com', 'Máquina Virtual');
INSERT INTO SERVICIO(fechaModificacion, etapa, correoElectronicoCliente, nombreTipoServicio)
VALUES ('2024-01-01', 'Producción', 'pepe@gmail.com', 'Servidor HTTP');
INSERT INTO SERVICIO(fechaModificacion, etapa, correoElectronicoCliente, nombreTipoServicio)
VALUES ('2024-01-01', 'Producción', 'pepe@gmail.com', 'Base de datos MySQL');
INSERT INTO SERVICIO(fechaModificacion, etapa, correoElectronicoCliente, nombreTipoServicio)
VALUES ('2024-01-01', 'Producción', 'pepe@gmail.com', 'Base de datos PostgreSQL');
INSERT INTO SERVICIO(fechaModificacion, etapa, correoElectronicoCliente, nombreTipoServicio)
VALUES ('2024-01-01', 'Producción', 'pepe@gmail.com', 'Máquina Virtual');

-- Insertar servidor HTTP
INSERT INTO SERVIDOR_HTTP (idServidor, puerto1, puerto2, directorioRaiz, estado, fechaCreacion, ipPublica, ipPrivada, protocoloTransporte, rutaConfiguracion, major, minor, patch)
VALUES (2,80, 443, '/var/www', 'Activo', '2024-01-01', '198.51.100.2', '10.0.0.2', 'TCP', '/etc/httpd/conf', 1, 0, 0);

-- Insertar motores de almacenamiento
INSERT INTO MOTOR_ALMACENAMIENTO (tamañoBufer, soporteTransaccion)
VALUES ('64 MB', TRUE);
INSERT INTO MOTOR_ALMACENAMIENTO (tamañoBufer, soporteTransaccion)
VALUES ('1 GB', TRUE);

-- Insertar INNODB
INSERT INTO INNODB (idMotorInnoDB) VALUES (1);

-- Insertar MYISAM
INSERT INTO MYISAM (idMotorMyIsam, recuperacionAutomatica) VALUES (2, FALSE);

-- Insertar plan de respaldo
INSERT INTO PLAN_RESPALDO (frecuencia, retencion)
VALUES ('Semanal', '90 días');

-- Insertar base de datos
INSERT INTO BASE_DE_DATOS (idBD, ipCliente, almacenamiento, PID, puerto, ipPublica, ipPrivada, protocoloTransporte, protocoloAplicacion, rutaConfiguracion, major, minor, patch, idPlan)
VALUES (3, '192.168.1.100', '50 GB', 1234, 5432, '203.0.113.1', '10.0.0.10', 'TCP', 'HTTPS', '/etc/db/conf', 1, 0, 0, 1);

INSERT INTO BASE_DE_DATOS (idBD, ipCliente, almacenamiento, PID, puerto, ipPublica, ipPrivada, protocoloTransporte, protocoloAplicacion, rutaConfiguracion, major, minor, patch, idPlan)
VALUES (4, '192.168.1.100', '50 GB', 1234, 5432, '203.0.113.2', '10.0.0.11', 'TCP', 'HTTPS', '/etc/db/conf2', 1, 0, 0, 1);

-- Insertar PostgreSQL
INSERT INTO POSTGRESQL (idBDPostgreSQL, encoding, conexionesMaximas, extension)
VALUES (4, 'UTF8', '100', 'PostGIS');

-- Insertar MySQL
INSERT INTO MYSQL (idBDMySQL, modo, idMotor) 
VALUES (3, 'STRICT', 1);

-- Insertar copia seguridad de BD
INSERT INTO COPIA_SEGURIDAD_BD (tipo, fecha, hora, ubicacion, tamaño, estado, idBD)
VALUES ('Completa', '2024-01-02', '00:00:00', '/backups', 2048, 'Exitosa', 3);

-- Insertar una copia seguridad para servicio, por si se requiere:
INSERT INTO COPIA_SEGURIDAD_SERVICIO (fecha, hora, estado, configuraciones, idServicio)
VALUES ('2024-01-02', '08:00:00', 'Exitosa', 'config default', 1);

-- Insertar sistema operativo 
INSERT INTO SISTEMA_OPERATIVO (nombreSO, major, minor, patch)
VALUES ('Ubuntu', 20, 4, 1);

-- Insertar máquina virtual
INSERT INTO MAQUINA_VIRTUAL (idMaquina, descripcion, host, ip, idSO) 
VALUES (1, '', 'vm-node-02', '10.0.0.1', 1);
INSERT INTO MAQUINA_VIRTUAL (idMaquina, descripcion, host, ip, idSO) 
VALUES (5, '', 'vm-node-02', '10.0.0.1', 1);

-- Insertar CONEXION_BD 
INSERT INTO CONEXION_BD (hora, fecha, idBD)
VALUES ('12:00:00', '2024-01-03', 3);

-- Insertar arquitectura
INSERT INTO ARQUITECTURA (etapa, tipo, idMaquina)
VALUES ('Producción', 'Microservicios', 1);

-- Insertar disco duro
INSERT INTO DISCO_DURO(etapa, tipo, capacidad, idMaquina)
VALUES ( 'Producción', 'SSD','128 GB' ,1);

-- Insertar CPU
INSERT INTO CPU (etapa, nucleos, generacion, idMaquina)
VALUES ( 'Producción', 8, 10, 1);

-- Insertar RAM
INSERT INTO RAM (etapa, capacidad, generacion, idMaquina)
VALUES ('Producción', '2 GB', 'DDR4', 1);

-- Insertar componente de red
INSERT INTO COMPONENTE_DE_RED(tipo, etapa, idMaquina)
VALUES ( 'NIC', 'Producción', 1);

-- Insertar CONEXION_HTTP 
INSERT INTO CONEXION_HTTP (hora, fecha, idServidor)
VALUES ('14:00:00', '2024-01-04', 2);

-- Insertar personal asignado a servicio
INSERT INTO PERSONAL_ASIGNADO_A_SERVICIO (correoElectronicoPersonal, idServicio) 
VALUES ('juan@gmail.com', 1);

-- Confirmar la transacción
COMMIT;

ROLLBACK;
