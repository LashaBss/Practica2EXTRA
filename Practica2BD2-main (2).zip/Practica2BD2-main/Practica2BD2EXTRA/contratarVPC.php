<?php
session_start();
require_once "conexion.php";

// Verificar si el usuario ha iniciado sesión y existe un idUsuario en la sesión
if (!isset($_SESSION['idUsuario'])) {
    header("Location: login.php");
    exit;
}

$idUsuari = $_SESSION['idUsuario'];

// Si se ha enviado el formulario, procesamos la inserción
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Recogemos y saneamos los datos del formulario
    $nom = trim($_POST['nom']);
    $supportIPv4 = isset($_POST['supportIPv4']) ? 1 : 0;
    $supportIPv6 = isset($_POST['supportIPv6']) ? 1 : 0;
    $cidrBlock   = trim($_POST['cidrBlock']);
    $regio       = trim($_POST['regio']);
    $status      = trim($_POST['status']);

    $idRuta       = isset($_POST['idRuta']) ? intval($_POST['idRuta']) : null;
    $idInternetGW = isset($_POST['idInternetGW']) ? intval($_POST['idInternetGW']) : null;
    $idEndpoint   = isset($_POST['idEndpoint']) ? intval($_POST['idEndpoint']) : null;

    $fechaAhora = date('Y-m-d H:i:s');

    if (empty($nom) || empty($cidrBlock) || empty($regio) || empty($status)) {
        $_SESSION['error'] = "Por favor, complete todos los campos obligatorios de la VPC.";
        header("Location: contratarVPC.php");
        exit;
    }

    // Insertar la nueva VPC
    $sqlVPC = "INSERT INTO VPC (
        nom,
        supportIPv4,
        supportIPv6,
        cidrBlock,
        regio,
        dataCreacio,
        dataModificacio,
        status,
        idRuta,
        idInternetGW,
        idUsuari,
        idEndpoint
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmtVPC = mysqli_prepare($con, $sqlVPC);
    if (!$stmtVPC) {
        $_SESSION['error'] = "Error al preparar la consulta de VPC: " . mysqli_error($con);
        header("Location: contratarVPC.php");
        exit;
    }

    // Reemplazamos "siiissssiiii" por "siisssssiiii"
    mysqli_stmt_bind_param(
        $stmtVPC,
        "siisssssiiii",  // <-- Cadena de tipos correcta
        $nom,
        $supportIPv4,
        $supportIPv6,
        $cidrBlock,
        $regio,
        $fechaAhora,
        $fechaAhora,
        $status,
        $idRuta,
        $idInternetGW,
        $idUsuari,
        $idEndpoint
    );

    if (!mysqli_stmt_execute($stmtVPC)) {
        $_SESSION['error'] = "Error al insertar la nueva VPC: " . mysqli_error($con);
        header("Location: contratarVPC.php");
        exit;
    }

    $nuevoIdVPC = mysqli_insert_id($con);
    mysqli_stmt_close($stmtVPC);

    // Crear un grupo de seguridad asociado (opcional)
    if (isset($_POST['crearGrupo']) && $_POST['crearGrupo'] === 'si') {
        $nomGrupo = trim($_POST['nomGrupo']);
        $descGrupo = trim($_POST['descGrupo']);

        if (!empty($nomGrupo)) {
            $sqlGrupo = "INSERT INTO GRUP_SEGURETAT (nom, descripcio, idVPC) VALUES (?, ?, ?)";
            $stmtGrupo = mysqli_prepare($con, $sqlGrupo);
            if ($stmtGrupo) {
                mysqli_stmt_bind_param($stmtGrupo, "ssi", $nomGrupo, $descGrupo, $nuevoIdVPC);

                if (!mysqli_stmt_execute($stmtGrupo)) {
                    $_SESSION['error'] = "VPC creada, pero error al crear el grupo de seguridad: " 
                                         . mysqli_error($con);
                    header("Location: contratarVPC.php");
                    exit;
                }
                mysqli_stmt_close($stmtGrupo);
            } else {
                $_SESSION['error'] = "VPC creada, pero error al preparar la consulta del grupo de seguridad: " 
                                     . mysqli_error($con);
                header("Location: contratarVPC.php");
                exit;
            }
        }
    }

    $_SESSION['exitoVPC'] = "¡VPC creada exitosamente! (ID: $nuevoIdVPC)";
    $_SESSION["idVPC"] = $nuevoIdVPC;
    header("Location: index.php");
    exit;
}

// Aquí se muestra el formulario si no se ha hecho POST
$sqlRutas = "SELECT idRuta, destinationCIDR FROM RUTA";
$resRutas = mysqli_query($con, $sqlRutas);

$sqlIGW = "SELECT idInternetGW, nom FROM INTERNET_GW";
$resIGW = mysqli_query($con, $sqlIGW);

$sqlEndpoint = "SELECT idEndpoint, endpointURL FROM ENDPOINT";
$resEndpoint = mysqli_query($con, $sqlEndpoint);

// Mensajes de error o éxito
if (isset($_SESSION['error'])) {
    echo "<p style='color: red;'>" . htmlspecialchars($_SESSION['error']) . "</p>";
    unset($_SESSION['error']);
}
if (isset($_SESSION['exitoVPC'])) {
    echo "<p style='color: green;'>" . htmlspecialchars($_SESSION['exitoVPC']) . "</p>";
    unset($_SESSION['exitoVPC']);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Contratar VPC</title>
</head>
<body>
    <h1>Contratar una nueva VPC</h1>
    <!-- Cambiar la acción al mismo archivo -->
    <form action="contratarVPC.php" method="POST">
        <label for="nom">Nombre de la VPC:</label><br>
        <input type="text" name="nom" id="nom" required><br><br>

        <label for="supportIPv4">¿Soporta IPv4?</label>
        <input type="checkbox" name="supportIPv4" id="supportIPv4" value="1"><br>

        <label for="supportIPv6">¿Soporta IPv6?</label>
        <input type="checkbox" name="supportIPv6" id="supportIPv6" value="1"><br><br>

        <label for="cidrBlock">CIDR Block:</label><br>
        <input type="text" name="cidrBlock" id="cidrBlock" placeholder="Ej: 10.0.0.0/16" required><br><br>

        <label for="regio">Región:</label><br>
        <input type="text" name="regio" id="regio" placeholder="Ej: us-east-1" required><br><br>

        <label for="status">Estado de la VPC:</label><br>
        <select name="status" id="status" required>
            <option value="">-- Seleccione --</option>
            <option value="Disponible">Disponible</option>
            <option value="En Creación">En Creación</option>
            <option value="Pendiente">Pendiente</option>
        </select><br><br>

        <label for="idRuta">Ruta asociada:</label><br>
        <select name="idRuta" id="idRuta" required>
            <option value="">-- Seleccione una ruta --</option>
            <?php
            if ($resRutas && mysqli_num_rows($resRutas) > 0) {
                while ($r = mysqli_fetch_assoc($resRutas)) {
                    echo "<option value='". $r['idRuta'] ."'>".
                         "ID " . $r['idRuta'] . " - CIDR: " . $r['destinationCIDR'] ."</option>";
                }
            }
            ?>
        </select><br><br>

        <label for="idInternetGW">Internet Gateway:</label><br>
        <select name="idInternetGW" id="idInternetGW" required>
            <option value="">-- Seleccione un IGW --</option>
            <?php
            if ($resIGW && mysqli_num_rows($resIGW) > 0) {
                while ($g = mysqli_fetch_assoc($resIGW)) {
                    echo "<option value='". $g['idInternetGW'] ."'>".
                         "ID " . $g['idInternetGW'] . " - " . $g['nom'] ."</option>";
                }
            }
            ?>
        </select><br><br>

        <label for="idEndpoint">Endpoint:</label><br>
        <select name="idEndpoint" id="idEndpoint" required>
            <option value="">-- Seleccione un Endpoint --</option>
            <?php
            if ($resEndpoint && mysqli_num_rows($resEndpoint) > 0) {
                while ($e = mysqli_fetch_assoc($resEndpoint)) {
                    echo "<option value='". $e['idEndpoint'] ."'>".
                         "ID " . $e['idEndpoint'] . " - " . $e['endpointURL'] ."</option>";
                }
            }
            ?>
        </select><br><br>

        <!-- ¿Crear grupo de seguridad asociado? -->
        <label for="crearGrupo">¿Crear un Grupo de Seguridad para esta VPC?</label>
        <input type="checkbox" name="crearGrupo" id="crearGrupo" value="si">
        <br><br>

        <div style="margin-left:20px;">
            <label for="nomGrupo">Nombre del Grupo:</label><br>
            <input type="text" name="nomGrupo" id="nomGrupo" placeholder="Nombre del grupo"><br><br>

            <label for="descGrupo">Descripción del Grupo:</label><br>
            <textarea name="descGrupo" id="descGrupo" rows="3" cols="30"
                      placeholder="Descripción del grupo de seguridad"></textarea><br><br>
        </div>

        <button type="submit">Crear VPC</button>
    </form>
</body>
</html>
<?php
mysqli_close($con);
?>
