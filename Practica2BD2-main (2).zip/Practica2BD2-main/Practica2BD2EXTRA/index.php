<?php 
session_start();
require_once "conexion.php";



if(isset($_SESSION["exitoVPC"])){
    echo "<h3>" . htmlspecialchars($_SESSION["exitoVPC"]) . "</h3>";

    unset($_SESSION["exitoVPC"]);
}


if (isset($_SESSION["error"])) {
    echo "<h3>" . htmlspecialchars($_SESSION["error"]) . "</h3>";

    unset($_SESSION["error"]);
}
$sql = "SELECT
    S.idServeiCataleg,
    S.NomServei,
    S.DescServei,
    S.etapa
FROM
    servei_cataleg S 
";
$resultado = mysqli_query($con, $sql);
$servicios = [];
while ($fila = mysqli_fetch_assoc($resultado)) {
    $servicios[] = $fila;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CatalogoTotCloud</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <?php
        require_once "header.php";
    ?>
    <!-- Catálogo de Productos -->
    <h1 class="Hregistro">Catálogo Tot Cloud</h1>
    <?php
        if (isset($_SESSION["grupo"]) && $_SESSION["grupo"] == "Administrador") {
            ?>
                <h2>Perfil de Administrador</h2>
            <?php
        } else if (isset($_SESSION["grupo"]) && $_SESSION["grupo"] == "Personal") {
            ?>
                <h2>Perfil de Personal</h2>
            <?php
        } else {
            ?>
                <h2>Consulta nuestros Servicios</h2>
            <?php
        }
    ?>
    <section class="catalog">
        <div class="productos-container">
            <?php foreach ($servicios as $servicio): ?>
                <div class="product">
                    <h3><?php echo htmlspecialchars($servicio['NomServei']); ?></h3>
                    <p><?php echo htmlspecialchars($servicio['DescServei']); ?></p>

                    <?php
                        // Guardar el servicio en la sesión
                        $_SESSION["servicio_" . $servicio['idServeiCataleg']] = $servicio;
                        
                        if (isset($_SESSION["tipoUsuario"]) && $_SESSION["tipoUsuario"] == "Personal") {
                            ?>   
                                <form action="EditarServicio.php" method="post">
                                    <!-- Enviar el ID del servicio para que se pueda editar correctamente -->
                                    <input type="hidden" name="idTipoServicio" value="<?php echo htmlspecialchars($servicio['idTipo']); ?>">

                                    <button type="submit">Editar Servicio</button>
                                </form>
                            <?php
                        } else {
                            ?>
                                <form action="ContratarServicio.php" method="post">
                                    <input type="hidden" name="TipoServicio" value="<?php echo htmlspecialchars($servicio['NomServei'], ENT_QUOTES, 'UTF-8'); ?>">
                                    <button type="submit">Contratar Servicio</button>
                                </form>

                            <?php
                        }
                    ?>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</body>
</html>
