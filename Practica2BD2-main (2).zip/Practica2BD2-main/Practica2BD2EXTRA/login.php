<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro y Catálogo</title>
    <link rel="stylesheet" href="css/estilos.css">
    <style>
       
    </style>
</head>
<body>
    <header class="Hregistro">
        <h1>Registro de Usuarios y Catálogo de Productos</h1>
    </header>

    <div class="container">
        <?php
        if (isset($_SESSION['error'])) {
            echo "<p style='color: red;'>" . $_SESSION['error'] . "</p>";
            unset($_SESSION['error']); // Borra el mensaje después de mostrarlo
        }
        ?>
        <!-- Formulario de Login -->
        <section class="form-container">
            <h2>Inicio de Sesión</h2>
            <form action="validaUsuario.php" method="POST">

                <label for="email">Correo electrónico:</label>
                <input type="email" id="email" name="email" required>

                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Iniciar Sesión</button>


            </form>
            <p>Si aún no está registrado: <a href="Registro.php" class="aLog">Crear cuenta</a> </p>
        </section>
