<?php
require_once "conexion.php";
session_start();

// Verificar si el usuario está identificado y existe un idUsuario en sesión
if (!isset($_SESSION['idUsuario'])) {
    $_SESSION["error"] = "PRIMERO TE TIENES QUE REGISTRAR";
    header("location: index.php");
    exit;
}

$idUsuari = $_SESSION['idUsuario'];

// 1. Comprobamos si el usuario tiene al menos una VPC
$queryVPC = "SELECT idVPC, nom FROM VPC WHERE idUsuari = ?";
$stmtVPC = mysqli_prepare($con, $queryVPC);
mysqli_stmt_bind_param($stmtVPC, "i", $idUsuari);
mysqli_stmt_execute($stmtVPC);
$resultVPC = mysqli_stmt_get_result($stmtVPC);

if (!$resultVPC) {
    die("Error al consultar las VPC: " . mysqli_error($con));
}

if (mysqli_num_rows($resultVPC) == 0) {
    // 2. No existe ninguna VPC, así que mostramos el mensaje y salimos
    echo "<h3>Debes contratar primero una VPC para alojar tus servicios. No puedes contratar ningún servicio sin tener al menos una VPC.</h3>";
    ?>
    <a href="contratarVPC.php">Contratar VPC</a>
    <?php
    exit;
}

// Verificamos si el formulario nos envió un TipoServicio
if (isset($_POST['TipoServicio'])) {
    $tipoServicio = htmlspecialchars($_POST['TipoServicio'], ENT_QUOTES, 'UTF-8');
    $_SESSION['TipoServicio'] = $tipoServicio; // Guardar en la sesión
} else {
    echo "<h3>No se seleccionó ningún servicio.</h3>";
    exit;
}
echo($_SESSION["TipoServicio"]);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>TotCloud - Contratar Servicio</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <h1>Contratar Servicio</h1>

    <form action="procesar_configuracion.php" method="POST">
        <label for="idVPC">Seleccionar la VPC en la que alojar el servicio:</label>
        <select name="idVPC" id="idVPC" required>
            <?php
            mysqli_data_seek($resultVPC, 0);
            while ($rowVPC = mysqli_fetch_assoc($resultVPC)) {
                echo "<option value='" . htmlspecialchars($rowVPC['idVPC'], ENT_QUOTES, 'UTF-8') . "'>" . htmlspecialchars($rowVPC['nom'], ENT_QUOTES, 'UTF-8') . "</option>";
            }
            ?>
        </select><br><br>
        <input type="hidden" name="TipoServicio" value="<?php echo htmlspecialchars($_SESSION['TipoServicio'], ENT_QUOTES, 'UTF-8'); ?>">
        <button type="submit">Continuar con la configuración</button>
    </form>
</body>
</html>
