<?php
global $con;
require_once "conexion.php";

session_start();

$sql= "SELECT
    S.NomServei,
    S.DescServei
FROM
    servei_cataleg S
WHERE
    S.tipusServei = 'PaaS';

";


$resultado= mysqli_query($con, $sql);
$servicios = [];
while ($fila = mysqli_fetch_assoc($resultado)) {
    $servicios[] = $fila;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CatalogoTotCloud</title>
    <link rel="stylesheet" href="CSS/estilos.css">
</head>
<body>
        <?php
            require_once "header.php";
        ?>
        <!-- Catálogo de Productos -->

        <h1 class="Hregistro">Catálogo PaaS</h1>
                <div class="product">
                        
                        <h3>Máquina Virtual</h3>
                        <p>Configure aquí su máquina Virtual</p>
                    <form action="ContratarServicio.php" method="post">
                        <input type="hidden" name="idTipoServicio" value="MV">
                        <button type="submit" name="Contratar">Contratar</button>
                    </form>
                </div>

                <div class="product">
                        
                        <h3>Infraestructura</h3>
                        <p>Configure aquí su Infraestructura de Computación</p>
                    <form action="ContratarServicio.php" method="post">
                        <input type="hidden" name="idTipoServicio" value="Infraestructura">
                        <button type="submit" name="Contratar">Contratar</button>
                    </form>
                </div>
                <?php foreach ($servicios as $servicio): ?>
                    <div class="product">
                        
                    <h3><?php echo htmlspecialchars($servicio['NomServei']); ?></h3>
                        <p><?php echo htmlspecialchars($servicio['DescServei']); ?></p>
                        <form action="ContratarServicio.php" method="post">
                <input type="hidden" name="idTipoServicio" value="<?php echo htmlspecialchars($servicio['NomServei'], ENT_QUOTES, 'UTF-8'); ?>">
                <button type="submit" name="Contratar">Contratar</button>
            </form>
                    </div>
                <?php endforeach; ?>
            </div>

            </div>
        </section>
    </div>
</body>
</html>
