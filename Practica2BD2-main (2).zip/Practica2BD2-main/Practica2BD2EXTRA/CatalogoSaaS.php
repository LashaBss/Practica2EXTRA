<?php
global $con;
require_once "conexion.php";

session_start();

$sql= "SELECT
    S.NomServei,
    S.DescServei
FROM
    servei_cataleg S
WHERE
    S.tipusServei = 'SaaS';

";


$resultado= mysqli_query($con, $sql);
$servicios = [];
while ($fila = mysqli_fetch_assoc($resultado)) {
    $servicios[] = $fila;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CatalogoTotCloud</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
        <?php
            require_once "header.php";
        ?>
        <!-- Catálogo de Productos -->

        <h1 class="Hregistro">Catálogo SaaS</h1>
        <section class="catalog">
            <?php
            
            ?>
            <div class="productos-container">
                <?php foreach ($servicios as $servicio): ?>
                    <div class="product">
                    <h3><?php echo htmlspecialchars($servicio['NomServei']); ?></h3>
                        <p><?php echo htmlspecialchars($servicio['DescServei']); ?></p>
                        <form action="ContratarServicio.php" method="post">
                <input type="hidden" name="idsTipoServicio" value="<?php echo htmlspecialchars($servicio['NomServei'], ENT_QUOTES, 'UTF-8'); ?>">
                <button type="submit" name="Contratar">Contratar</button>
            </form>
                    </div>
                <?php endforeach; ?>
            </div>

            </div>
        </section>
    </div>
</body>
</html>




