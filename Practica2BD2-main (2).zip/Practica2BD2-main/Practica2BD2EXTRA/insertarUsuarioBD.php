<?php
global $con;
session_start(); // Inicia la sesión
require_once "conexion.php";

// Recogemos los datos del formulario
$nombre = trim($_POST["nombre"]);
$apellido1 = trim($_POST["apellido1"]);
$apellido2 = trim($_POST["apellido2"]);
$email = trim($_POST["email"]);
$Ntelefono = trim($_POST["Ntelefono"]);
$password = trim($_POST["password"]);
$org = trim($_POST["empresa"]);
$tipo = (strpos($email, '@TotCloud.com') !== false) ? 'Personal' : 'Client'; // Determinar si es Personal o Cliente

// Validar que los datos no estén vacíos
if (empty($nombre) || empty($apellido1) || empty($email) || empty($Ntelefono) || empty($password) || empty($org)) {
    $_SESSION['error'] = "Por favor, complete todos los campos.";
    header("Location: Registro.php"); // Redirige de vuelta al formulario
    exit;
}

// Encriptamos la contraseña
$password_hash = password_hash($password, PASSWORD_BCRYPT);

// Escapamos los valores para evitar inyección SQL
$org = mysqli_real_escape_string($con, $org);
$email = mysqli_real_escape_string($con, $email);

// Ejecutamos la consulta para obtener el idOrganitzacio
$sql1 = "SELECT o.idOrganitzacio, o.nomOrganitzacio FROM organitzacio o WHERE o.nomOrganitzacio = ?";
$stmt1 = mysqli_prepare($con, $sql1);

if (!$stmt1) {
    $_SESSION['error'] = "Error al preparar la consulta: " . mysqli_error($con);
    header("Location: Registro.php");
    exit;
}

// Asociamos el parámetro y ejecutamos la consulta
mysqli_stmt_bind_param($stmt1, "s", $org);
mysqli_stmt_execute($stmt1);
$result1 = mysqli_stmt_get_result($stmt1);

if ($result1 && mysqli_num_rows($result1) > 0) {
    // Si la organización ya existe, obtenemos su id
    $row = mysqli_fetch_assoc($result1);
    $idOrganitzacio = $row['idOrganitzacio'];
} else {
    // Si la organización no existe, redirigimos con un mensaje de error
    $_SESSION['error'] = "La organización proporcionada no existe. Por favor, registre primero la organización.";
    header("Location: Registro.php");
    exit;
}

// Cerramos el statement de la primera consulta
mysqli_stmt_close($stmt1);

// Preparamos la consulta para insertar el usuario
$sql2 = "INSERT INTO usuari (correuElectronic, contrasenya, nom, cognom1, cognom2, numeroTelefon, tipusUsuari, idOrganitzacio)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt2 = mysqli_prepare($con, $sql2);

if (!$stmt2) {
    $_SESSION['error'] = "Error al preparar la consulta de inserción de usuario: " . mysqli_error($con);
    header("Location: Registro.php");
    exit;
}

// Asociamos los parámetros para insertar el usuario
mysqli_stmt_bind_param($stmt2, "sssssssi", $email, $password_hash, $nombre, $apellido1, $apellido2, $Ntelefono, $tipo, $idOrganitzacio);

// Ejecutamos la consulta y verificamos el resultado
if (mysqli_stmt_execute($stmt2)) {
    // Obtener el ID del usuario recién insertado
    $idUsuario = mysqli_insert_id($con);

    // Guardar el id del usuario en la sesión
    $_SESSION["idUsuario"] = $idUsuario;

    // Guardar también el nombre y correo (opcional)
    $_SESSION["nombreUsuario"] = $nombre;
    $_SESSION["emailUsuario"] = $email;

    //Guardamos el tipo de Usuario
    $_SESSION["tipoUsuario"]= $tipo;
    // Redirigir al catálogo de clientes si el registro fue exitoso
    header("Location: index.php");
    exit;
} else {
    $_SESSION['error'] = "Error al registrar usuario: " . mysqli_error($con);
    header("Location: Registro.php");
    exit;
}

// Cerramos el statement de la inserción y la conexión
mysqli_stmt_close($stmt2);
mysqli_close($con);
?>
