<?php
session_start();

// Asegúrate de que en algún punto de tu código se establezca $_SESSION["TipoServicio"]
// Ejemplo: $_SESSION["TipoServicio"] = "ServBBDD";

if (isset($_SESSION['TipoServicio'])) {
    switch ($_SESSION["TipoServicio"]) {
        
        /* =========================================
         * 1) CASO ServBBDD (MySQL)
         * ========================================= */
        case 'ServBBDD':
            ?>
            <form action="InsertarConfig.php" method="POST">
                <!-- Campos ocultos para indicar el tipo de servicio -->
                <input type="hidden" name="TipoServicio" value="ServBBDD">

                <h2>Configuración avanzada para MySQL</h2>

                <label for="ipCliente">IP Cliente:</label>
                <input type="text" name="ipCliente" id="ipCliente" required><br>

                <label for="almacenamiento">Almacenamiento (GB):</label>
                <input type="number" name="almacenamiento" id="almacenamiento" required><br>

                <label for="PID">PID:</label>
                <input type="number" name="PID" id="PID" required><br>

                <label for="puerto">Puerto:</label>
                <input type="number" name="puerto" id="puerto" required><br>

                <label for="ipPublica">IP Pública:</label>
                <input type="text" name="ipPublica" id="ipPublica" required><br>

                <label for="ipPrivada">IP Privada:</label>
                <input type="text" name="ipPrivada" id="ipPrivada" required><br>

                <label for="protocoloTransporte">Protocolo de transporte:</label>
                <select name="protocoloTransporte" id="protocoloTransporte" required>
                    <option value="IL">IL</option>
                    <option value="SPX">SPX</option>
                    <option value="SCTP">SCTP</option>
                    <option value="TCP">TCP</option>
                    <option value="UDP">UDP</option>
                    <option value="iSCSI">iSCSI</option>
                    <option value="DCCP">DCCP</option>
                </select><br>

                <label for="protocoloAplicacion">Protocolo de aplicación:</label>
                <select name="protocoloAplicacion" id="protocoloAplicacion" required>
                    <option value="DHCP">DHCP</option>
                    <option value="DNS">DNS</option>
                    <option value="HTTP">HTTP</option>
                    <option value="HTTPS">HTTPS</option>
                    <option value="POP3">POP3</option>
                    <option value="SMTP">SMTP</option>
                    <option value="Telnet">Telnet</option>
                </select><br>

                <button type="submit">Guardar Configuración</button>
            </form>
            <?php
            break;
        
        /* =========================================
         * 2) CASO Moodle
         * ========================================= */
        case 'Moodle':
            ?>
            <form action="InsertarConfig.php" method="POST">
                <!-- Indicamos que es Moodle -->
                <input type="hidden" name="TipoServicio" value="Moodle">

                <h2>Configuración avanzada para Moodle</h2>
                
                <!-- Por ejemplo, la tabla MOODLE pide "idioma" y "idServeiConfig".
                     Ajusta esto a los campos que quieras en tu formulario. -->
                <label for="idiomaMoodle">Idioma:</label>
                <input type="text" name="idiomaMoodle" id="idiomaMoodle" placeholder="ej: es, en, fr..." required><br>

                <label for="idServeiConfigMoodle">ID Servicio Config (FK):</label>
                <input type="number" name="idServeiConfigMoodle" id="idServeiConfigMoodle" required><br>

                <button type="submit">Guardar Configuración Moodle</button>
            </form>
            <?php
            break;

        /* =========================================
         * 3) CASO Odoo
         * ========================================= */
        case 'Odoo':
            ?>
            <form action="InsertarConfig.php" method="POST">
                <input type="hidden" name="TipoServicio" value="Odoo">
                
                <h2>Configuración avanzada para Odoo</h2>
                
                <!-- Tabla ODDO: modulsActius, idServeiConfig -->
                <label for="modulosActivos">Módulos activos (separados por comas):</label>
                <input type="text" name="modulosActivos" id="modulosActivos" placeholder="ej: Contabilidad,CRM" required><br>

                <label for="idServeiConfigOdoo">ID Servicio Config (FK):</label>
                <input type="number" name="idServeiConfigOdoo" id="idServeiConfigOdoo" required><br>

                <button type="submit">Guardar Configuración Odoo</button>
            </form>
            <?php
            break;

        /* =========================================
         * 4) CASO Matomo
         * ========================================= */
        case 'Matomo':
            ?>
            <form action="InsertarConfig.php" method="POST">
                <input type="hidden" name="TipoServicio" value="Matomo">

                <h2>Configuración avanzada para Matomo</h2>

                <!-- Tabla MATOMO: dominiMonitoritzat, politicaRetencio, idServeiConfig -->
                <label for="dominioMonitorizado">Dominio Monitorizado:</label>
                <input type="text" name="dominioMonitorizado" id="dominioMonitorizado" placeholder="ej: midominio.com" required><br>

                <label for="politicaRetencion">Política de Retención:</label>
                <input type="text" name="politicaRetencion" id="politicaRetencion" placeholder="ej: 30days, 60days..." required><br>

                <label for="idServeiConfigMatomo">ID Servicio Config (FK):</label>
                <input type="number" name="idServeiConfigMatomo" id="idServeiConfigMatomo" required><br>

                <button type="submit">Guardar Configuración Matomo</button>
            </form>
            <?php
            break;
        
        /* =========================================
         * DEFAULT
         * ========================================= */
        default:
            echo "<p>Tipo de servicio no reconocido.</p>";
            break;
    }
}
?>
