<?php
session_start();

// Conexión a la base de datos
$host     = "localhost";
$user     = "root";
$password = "";
$database = "tot_cloud";

$con = mysqli_connect($host, $user, $password, $database);
if (!$con) {
    // Guardar error en sesión y redirigir
    $_SESSION["error"] = "Error de conexión: " . mysqli_connect_error();
    header("Location: index.php");
    exit;
}

// Verificamos si recibimos el tipo de servicio
if (!isset($_POST['TipoServicio'])) {
    $_SESSION["error"] = "No se ha recibido el tipo de servicio.";
    header("Location: index.php");
    exit;
}

$tipoServicio = $_POST['TipoServicio'];

// 1) Insertar en SERVEI_CONFIGURACIO
$sqlConfig = "INSERT INTO SERVEI_CONFIGURACIO (
    dataCreacio, 
    dataModificacio,
    idEndpoint,
    idServeiCatalog,
    idVPC,
    idInfraestructura
) VALUES (
    NOW(),
    NOW(),
    1, 
    1,
    1,
    1
)";

if (!mysqli_query($con, $sqlConfig)) {
    $_SESSION["error"] = "Error al insertar en SERVEI_CONFIGURACIO: " . mysqli_error($con);
    header("Location: index.php");
    exit;
}

// Obtenemos el ID recién creado
$idServeiConfig = mysqli_insert_id($con);

// 2) Insertar los datos específicos según el tipo
switch ($tipoServicio) {
    case 'ServBBDD':
        $ipCliente           = mysqli_real_escape_string($con, $_POST['ipCliente']);
        $almacenamiento      = (int)$_POST['almacenamiento'];
        $PID                 = (int)$_POST['PID'];
        $puerto              = (int)$_POST['puerto'];
        $ipPublica           = mysqli_real_escape_string($con, $_POST['ipPublica']);
        $ipPrivada           = mysqli_real_escape_string($con, $_POST['ipPrivada']);
        $protocoloTransporte = mysqli_real_escape_string($con, $_POST['protocoloTransporte']);
        $protocoloAplicacion = mysqli_real_escape_string($con, $_POST['protocoloAplicacion']);
        
        // Ejemplo: suponiendo la tabla es "BASE_DE_DADES"
        $sqlBd = "INSERT INTO BASE_DE_DADES (
            nom,
            tipusBD,
            backupAutomatic,
            tamanyMax,
            idServeiConfig
        ) VALUES (
            'ServicioMySQL',
            'MySQL',
            TRUE,
            $almacenamiento,
            $idServeiConfig
        )";

        if (!mysqli_query($con, $sqlBd)) {
            $_SESSION["error"] = "Error al insertar en BASE_DE_DADES: " . mysqli_error($con);
            header("Location: index.php");
            exit;
        }
        break;
    
    case 'Moodle':
        $idiomaMoodle = mysqli_real_escape_string($con, $_POST['idiomaMoodle']);
        $sqlMoodle = "INSERT INTO MOODLE (
            idioma,
            idServeiConfig
        ) VALUES (
            '$idiomaMoodle',
            $idServeiConfig
        )";

        if (!mysqli_query($con, $sqlMoodle)) {
            $_SESSION["error"] = "Error al insertar en MOODLE: " . mysqli_error($con);
            header("Location: index.php");
            exit;
        }
        break;

    case 'Odoo':
        $modulosActivos = mysqli_real_escape_string($con, $_POST['modulosActivos']);
        $sqlOdoo = "INSERT INTO ODDO (
            modulsActius,
            idServeiConfig
        ) VALUES (
            '$modulosActivos',
            $idServeiConfig
        )";

        if (!mysqli_query($con, $sqlOdoo)) {
            $_SESSION["error"] = "Error al insertar en ODDO: " . mysqli_error($con);
            header("Location: index.php");
            exit;
        }
        break;

    case 'Matomo':
        $dominio     = mysqli_real_escape_string($con, $_POST['dominioMonitorizado']);
        $politicaRet = mysqli_real_escape_string($con, $_POST['politicaRetencion']);
        
        $sqlMatomo = "INSERT INTO MATOMO (
            dominiMonitoritzat,
            politicaRetencio,
            idServeiConfig
        ) VALUES (
            '$dominio',
            '$politicaRet',
            $idServeiConfig
        )";

        if (!mysqli_query($con, $sqlMatomo)) {
            $_SESSION["error"] = "Error al insertar en MATOMO: " . mysqli_error($con);
            header("Location: index.php");
            exit;
        }
        break;

    default:
        $_SESSION["error"] = "Tipo de servicio no reconocido: $tipoServicio";
        header("Location: index.php");
        exit;
}

// 3) Si todo salió bien, guardamos mensaje de éxito
$_SESSION["exitoVPC"] = "¡Se ha insertado la configuración de $tipoServicio correctamente!";

// Cerramos conexión
mysqli_close($con);

// 4) Redireccionamos a index.php
header("Location: index.php");
exit;
