<?php
global $con;
session_start();
require_once "conexion.php";

// Verificar conexión
if (!$con) {
    $_SESSION['error'] = "Error de conexión a la base de datos: " . mysqli_connect_error();
    header("Location: login.php");
    exit;
}

// Obtener los datos del formulario
$email = isset($_POST["email"]) ? $_POST["email"] : '';
$password = isset($_POST["password"]) ? $_POST["password"] : '';

// Validar campos vacíos
if (empty($email) || empty($password)) {
    $_SESSION['error'] = "Por favor, complete todos los campos.";
    header("Location: login.php");
    exit;
}

// Consulta para traer el usuario por correo
$sql = "SELECT idUsuari, correuElectronic, contrasenya, nom, tipusUsuari
        FROM USUARI
        WHERE correuElectronic = ?";
$stmt = mysqli_prepare($con, $sql);

if (!$stmt) {
    $_SESSION['error'] = "Error al preparar la consulta: " . mysqli_error($con);
    header("Location: login.php");
    exit;
}

// Asociar parámetros (tipo 's' para string)
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);

// Verificar si se encontró el usuario
if ($fila = mysqli_fetch_assoc($resultado)) {


    // Verificar la contraseña cifrada
    if (password_verify($password, $fila['contrasenya'])) {
        // Inicio de sesión exitoso
        $_SESSION["idUsuario"]= $fila["idUsuari"];
        $_SESSION['nombreUsuario'] = $fila["nom"];
        $_SESSION['emailUsuario']   = $fila["correuElectronic"];
        $_SESSION["tipo"]= $fila["tipusUsuari"];
        header("Location: index.php");
        exit;
    } else {

        // Contraseña incorrecta
        $_SESSION['error'] = "contraseña incorrectos.";
        header("Location: login.php");
        exit;
    }
} else {
    // Usuario no encontrado
    $_SESSION['error'] = "Correo o contraseña incorrectos.";
    header("Location: login.php");
    exit;
}

// Cerrar la conexión
mysqli_stmt_close($stmt);
mysqli_close($con);
?>
