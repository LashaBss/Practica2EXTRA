
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo Tot Cloud</title>
    <link rel="stylesheet" href="CSS/estilos.css">
    <!-- Bootstrap CSS desde CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Iconos Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }
        .navbar {
            background-color: #4A90E2; /* Color azul atractivo */
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: white !important;
        }
        .nav-link {
            color: white !important;
            transition: color 0.3s;
        }
        .nav-link:hover {
            color: #FFD700 !important; /* Color dorado al pasar el cursor */
        }
        .dropdown-menu {
            background-color: #4A90E2; /* Fondo azul para el menú desplegable */
        }
        .dropdown-item {
            color: white !important;
        }
        .dropdown-item:hover {
            background-color: #FFD700; /* Fondo dorado al pasar el cursor */
            color: black !important;
        }
        .navbar-text {
            color: white;
            font-weight: bold;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Título del catálogo -->
                <a class="navbar-brand" href="index.php">Catálogo Tot Cloud</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <!-- Navegación principal -->
                    <ul class="navbar-nav me-auto">
                        
                            <li class="nav-item"><a class="nav-link" href="CatalogoSaas.php" name="Catalogo SaaS">Catálogo SaaS</a></li>
                            <li class="nav-item"><a class="nav-link" href="CatalogoPaas.php" name="Catalogo PaaS">Catálogo PaaS</a></li>
                        
                    </ul>
                    <!-- Menú dinámico -->
                    <ul class="navbar-nav ms-auto">
                        <?php if (isset($_SESSION['idUsuario'])): ?>
                            <li class="nav-item">
                                <span class="navbar-text">Hola, <?php echo htmlspecialchars($_SESSION['nombreUsuario']); ?></span>
                            </li>
                            
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="userMenu" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-person-circle"></i> <!-- Ícono de usuario -->
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
                                    
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="logout.php">Cerrar Sesión</a></li>
                                    <?php 
                            
                                        if($_SESSION["tipoUsuario"]=="Personal"){
                                    ?>
                                            <li><a href="RevisarComponentes.php">Revisar Componentes</a></li>
                                    <?php
                                        }
                            
                                    ?>
                                </ul>
                            </li>

                            
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link" href="login.php"><i class="bi bi-box-arrow-in-right"></i> Iniciar Sesión</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>  

    <!-- Enlace a Bootstrap JS desde CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
